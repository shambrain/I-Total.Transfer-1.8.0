# Release acceptance checklist

Audited **2026-10-19** against version **1.8.0** (unreleased) on the build machine: Windows 10 build 19045,
.NET 10, display scaling 150% (DPI 144). Every line below is either ticked **with the evidence that proves it
named**, or left unticked and labelled with exactly what it is waiting for. Nothing is ticked on the strength
of "it should work" — where the only evidence is a mock, a mock, or a code inspection, that is said so.

**Legend** — ✅ proven (evidence named) · 🟡 proven in part, or proven only against a mock / by inspection ·
⛔ blocked on the handset (nothing attached at audit time) · ❌ not implemented.

## Candidate note (2026-10-29)

A new candidate executable (`1C62B2B1...`, 112,260,934 B) was built from the master-directive work:
zero-byte/unknown-size separation, shared enumeration accounting, SQLite integrity columns with migration,
the reconciliation report, retry classification, stability timestamps, WPD COM cleanup and accessible
control names. Build 0/0, suite 488 passed / 2 skipped / 490, source-ZIP rebuild byte-identical, installer
install/uninstall re-verified. **No physical device was attached for this candidate**, so every hardware
row below keeps its earlier status and none is promoted by this build. The checklist itself has not been
re-audited line by line for this candidate.
## Correctness

- [x] **Empty scan cannot start a backup.** ✅
  `TransferEngineTests.EmptyScanIsRejectedRatherThanReportedComplete`,
  `TransferRulesTests.EmptyPlanCannotBeComplete`, `CompletionRequiresNonEmptyPlanAndAllItemsProcessed`.
- [x] **Any enumeration failure blocks a "complete scan" state.** ✅
  `FilterAndConflictTests.EnumerationClassificationDistinguishesEmptyIncompleteAndComplete`; all three backends
  feed their folder failures and duplicate count through `TransferRules.ClassifyEnumeration`
  (`ShellIPhoneDevice.cs:180`, `WpdDevice.cs:151`, `AfcDevice.cs:132`), and `ScanResult.IsComplete` is derived
  from it, so a partial walk can never be presented as complete.
- [x] **Nested folders are recursively enumerated and mapped to safe destination paths.** ✅
  `TransferRulesTests.NestedMediaFolderIsPreservedSafely`, `NestedTraversalIsRejected`, `TraversalFilenameIsRejected`,
  `AbsoluteSourceFolderIsRejected`; `LargeLibraryStressTests.ScanningASingleFolderOfTwentySixThousandEntriesCompletesAndReportsProgress`;
  WPD walks the object tree in `EnumerateRecursive`.
- [x] **No source object/path is silently deduplicated; duplicate destination paths are reported.** ✅
  Every backend names the duplicate paths in a warning and classifies the scan **Incomplete**
  (`ShellIPhoneDevice.cs:170`, `WpdDevice.cs:145`, `AfcDevice.cs:129`); `ManifestStore.LoadOrCreate` refuses a
  manifest that already contains a duplicate and preserves it as evidence. *Residual, stated plainly:* if the
  operator chooses to copy a **warned** partial listing, the manifest keeps one entry per path — the duplicate
  was named before that decision was taken, so it is not silent, but the engine does not re-ask.
- [x] **Existing destination files are preserved by default; same-size files are labelled size-matched only.** ✅
  `FilterAndConflictTests.PreservePolicyNeverRenames`, `ExistingDestinationClassificationIsConservative`;
  `ReconciliationTests.NoSavedHash_WithMatchingSize_RecordsBaseline`, `SizeMatches_WithoutAnyHash_IsOnlySizeOnly`;
  `TransferEngineTests.ExistingCollisionIsPreservedAndReportedFailed`.
- [x] **Partial files are never finalized before stream closure and verification.** ✅
  The copy writes `<name>.partial`, checks the streamed length against the scan, flushes, then moves it into
  place (`WpdDevice.CopyToStage`); `RecoveryFlowTests.StoppingATransferRecordsWhatFinishedAndWhatDidNot` shows
  the destination holds only what was verified.
- [x] **Cancellation, crash and USB disconnect persist an incomplete state and permit safe resume.** ✅ *(disconnect proven in part)*
  `RecoveryFlowTests` (6) and `SessionRecoveryTests` (14): the session is stamped `RUNNING` before the first
  byte, `CANCELLED` on Stop and `ABORTED` on a fault, and a stopped session still reaches a verified-complete
  result. A backend fault stands in for a cable pull 🟡; the real pull is ⛔ (needs the handset).
- [x] **No session is complete if any planned file is failed, inaccessible or unverifiable.** ✅
  `TransferRulesTests.CompletionFailsIfAnyItemFailed`, `CompletionFailsIfAnyItemWasInaccessible`;
  `RecoveryFlowTests.ARecordedEntryThatCanNeverBeCopiedKeepsTheSessionFromClaimingCompletion`. A continued run
  takes its verdict from the **whole** manifest, not just its own work.
- [x] **The app distinguishes "all exposed items copied" from "entire Photos library backed up".** 🟡 *(wording; not machine-checked)*
  The enumeration report is a self-describing "exposed" count, the group taglines say "exposed through DCIM",
  the Overview reads "Total exposed media size", `ConnectionDiagnostics` labels iCloud originals **MANUAL CHECK**,
  and `README.md` states that a scan is not proof that cloud-only originals were downloaded. There is no test
  that can assert a sentence, so this stays half-ticked rather than claimed.

## Performance

- [x] **No per-file O(n) manifest search.** ✅
  The copy loop works from `ManifestStore.Index()` (a dictionary keyed by relative path); `ManifestStore.Find`
  is a linear scan but has no caller in the engine. Measured: `EngineThroughputBenchmarkTests` sustains
  **660 files/s** over 4,000 small files with source-and-destination hashing.
- [x] **No per-file full-folder enumeration on the normal source lookup path.** ✅ *(live path)* / ⛔ *(resume path, device effect)*
  A live copy opens the object id the scan recorded — one `GetStream`, no walk (`WpdDevice.OpenSourceStream`).
  The **resume** path cannot use those ids (they do not survive a reconnect), so it resolves each file by path,
  and that lookup used to re-walk the album and read a property per sibling **for every file** — quadratic in
  the album. `FolderNameIndex` now reads each folder once per session and answers from memory;
  `FolderNameIndexTests` pins the property directly (26,100 files across three albums cost **4** folder reads,
  not 26,100). The device-side gain still needs the drill ⛔.
- [x] **GUI update cadence is bounded; logs do not flush for every buffer read.** ✅
  `ThrottledProgressTests` (5); measured — the engine emits 4,000 updates for 4,000 files and the UI receives
  **21** (`EngineThroughputBenchmarkTests.ProgressReportingIsBoundedRatherThanOneUpdatePerFile`). The log keeps
  one writer open, appends a line per event and decides rollover from a byte count, so no buffer read touches it.
- [x] **Benchmark 64 KiB, 256 KiB, 1 MiB and 4 MiB buffers on actual devices.** LIVE PASS on the HUAWEI
  Y7 Prime 2018 over native WPD: one 612,420,912-byte MP4, source/destination hash verified, 64 KiB
  18.246 s / 33.56 MB/s; 256 KiB 16.911 s / 36.21 MB/s; 1 MiB 16.369 s / 37.41 MB/s; 4 MiB 16.187 s /
  37.83 MB/s; CPU 2.94-6.50 s, peak working set 70.1-85.5 MB. One run per buffer on one device; the iPhone
  was not benchmarked and this is not a statistical result.
- [x] **Record device/iOS/Windows/USB/destination context for benchmark results.** The Android runs record
  the device (`HUAWEI Y7 Prime 2018`, Android/MTP), backend (native WPD), host (Windows 10 22H2), buffer,
  file count and bytes, destination (local NTFS temp folder), elapsed time, CPU and peak working set. The
  physical USB port/cable and any iOS benchmark are not recorded; no uncontextualised number is published.
- [x] **Do not enable multi-file concurrent reads
  on a single device session until tests prove it safe.** ✅
  There is no concurrent copy path to enable: `TransferService` runs one sequential loop and uses `Task.Run`
  only to keep blocking device calls off the UI thread. The value is forced to 1 on save
  (`SettingsPage.cs:359`) and the control says so.

## Device and failure testing

- [x] **iPhone not connected / locked / not trusted / DCIM unavailable.** 🟡 *(two of four proven live)*
  *Not connected* ✅ live 2026-10-19: the tiles read "Connect your iPhone", the band stayed idle and the
  **Resume transfer** action was visible-but-disabled. *DCIM unavailable* ✅ live: this handset exposes no
  `DCIM` container at all, and `CameraRoll` accepts the storage container that holds the albums while keeping
  the canonical `DCIM` label — detection was fixed for exactly this. *Locked* and *not trusted* 🟡: the code
  paths return `LockedOrUntrusted` with unlock/Trust guidance, but were never provoked on hardware.
- [ ] **Apple device software missing or repair needed.** ⛔ Needs a machine with no Apple portable-device stack.
- [x] **USB disconnect at scan, copy and verify phases.** 🟡 *(the scan phase happened for real and found a defect)*
  On 2026-10-20 a phone was physically disconnected while a 52,574-file scan was finishing. The scan had
  reported `status=Complete`; every object read after the cable moved then failed, each failure was recorded
  as one warning, and the album stayed marked as read — so a listing missing the tail of the tree called
  itself complete, and the cache stored it. Fixed: an unreadable object marks its folder a failed read (the
  scan becomes `Incomplete`), twenty consecutive failures abort the walk with
  `DeviceStoppedAnsweringException` and a reconnect instruction, and nothing incomplete reaches the cache.
  `TransferRules.DeviceStoppedAnswering` + `FilterAndConflictTests` pin the rule; the fixed run has not been
  re-observed live, and a cable pull mid-**copy**/**verify** remains ⛔ (those go through the backend-fault
  path pinned by `RecoveryFlowTests.ABackendFaultAbortsTheSessionAndLeavesItResumable`).
- [x] **Destination full, read-only, permission denied, long path and invalid name.** 🟡 *(paths and names proven; volume conditions not provoked)*
  Long/reserved/invalid names and traversal: `ReconciliationTests` (reserved-name set, trailing space/dot,
  control characters), `TransferRulesTests` (traversal, absolute folders). Full/read-only/permission-denied:
  a failing entry is recorded as failed and the session cannot claim completion
  (`CompletionFailsIfAnyItemFailed`) — but no run was performed against a full or write-protected volume.
- [x] **Same path + same size but different content is not described as hash verified.** ✅
  `FilterAndConflictTests.VerificationClassificationNeverUpgradesWithoutMatchingHashes`;
  `ReconciliationTests.SavedHashDiffersFromExistingHash_PreservesForReview`.
- [x] **Scan changed between passes; warning shown and plan can be refreshed.** ✅ *(logic proven; device trigger ⛔)*
  The second pass runs when asked (`MainForm.cs:629`), compares the two enumerations and refuses the plan with
  the changed paths named. The comparison is now linear — `ScanStabilityTests` (6), including the measured
  26,000-path case — and it no longer throws on a partial scan that carries a duplicate path.
- [x] **iCloud Photos with Optimize Storage; clear guidance without claiming automatic detection is definitive.** ✅ *(guidance)* / ⛔ *(a genuinely cloud-optimized library)*
  `ConnectionDiagnostics` lists iCloud originals as a **MANUAL CHECK** with Apple's "Download and Keep
  Originals" wording; the backends say the same in their empty/inaccessible messages; `README.md:265` states
  a scan is not proof that cloud-only originals came down. No automatic detection is claimed anywhere.
- [x] **HEIC/JPEG and MOV pairs remain individually preserved and are reported as possible Live Photo pairs.** ✅
  `FilterAndConflictTests.LivePhotoPairsAreCountedByStem`; `EnumerationReport.LivePhotoPairCount`;
  `CameraRollTests.CameraMediaIsPhotosAndVideosOnly` (pairs are never merged).
- [x] **Large video (4 GB+) and 25,000+ item library.** 🟡 *(25,000+ proven twice; 4 GB+ file not copied)*
  `LargeLibraryStressTests.ScanningASingleFolderOfTwentySixThousandEntriesCompletesAndReportsProgress` (26,000
  entries), `SummarisingAndFilteringThreeHundredThousandEntriesStaysLinear` (300,000), and live scans:
  a cold **55,185 files / 162,499,726,120 bytes (151.34 GiB) in 23.3 minutes** on 2026-10-22, plus historical
  **26,335 files / 106.49 GB in 10.3 minutes**, **52,574 files / 166.72 GB in 23.2 minutes** and a warm
  **57,371-file** pass. For 4 GB+ the 32-bit concern is covered
  (`OperationStatusTests.AByteTotalBeyondIntRangeStillProducesAPosition`),
  but the largest file any automated test copies is 32 MiB, so a single 4 GB+ video is ⛔.

## Connection diagnosis and support bundle

- [x] **A device Windows merely remembers is never reported as a device that is attached.** ✅
  The most confusing state in the field: Device Manager still lists an "Apple iPhone" — its own properties
  reading *"Currently, this hardware device is not connected to the computer"* — while the application says no
  device is present, and neither statement is false. `Core/AttachmentDiagnosis.cs` now keeps the two facts
  apart: the handsets answering a live probe, and the records Windows is merely holding. Handsets are decided
  from the **driver service** bound to each record (`WUDFWpdMtp` is the media interface; the composite parent,
  Apple's USB driver and usbmuxd are support interfaces that can never supply a file), so the reading does not
  depend on Apple's display names, and an attached handset is never downgraded by stale records beside it.
  Verified against this machine's **real** USB registry rather than a fixture: the Diagnostics page and the
  bundle both read `CACHED RECORD ONLY (2)` — *Apple iPhone, Apple iPad* — with 3 support records and nothing
  attached. `AttachmentDiagnosisTests` (10) uses that same record set, and the live read is asserted to return
  display names only, never the instance key Windows stores the serial number in.
- [x] **The attached branch of that diagnosis on a live handset.** LIVE PASS on 2026-10-24 with both phones
  attached. The AppleFirst run produced 10 checks: Apple handsets `ATTACHED` (naming the two support
  interfaces that cannot supply media), Windows device access `PASS`, family `APPLE`, software `DETECTED`,
  drivers `FOUND`, trust `ACCESSIBLE`; the summary read `Attached: HUAWEI Y7 Prime 2018 (Android), Apple iPhone
  (Apple).` With only the HUAWEI attached the same page produced its 8 Android rows, named the HUAWEI alone and
  showed no Apple rows. The same run found `Native AFC runtime: VERIFIED` beside a sentence saying no binary
  was verified; a repeat run after the fix showed `NOT PRESENT`. Attached-but-locked and unplugged variants remain open
  (TEST-PLAN check 24).
- [x] **The diagnostics page shows its findings whole.** ✅
  The detail column neither wrapped nor grew, so any finding longer than the column was silently truncated with
  nothing to say it had been — the worst failure mode for a page whose entire purpose is to explain a fault.
  Details now wrap and their rows grow, in both the check and the dependency grids, and the three USB readings
  are coloured apart (green attached, amber remembered-only, red never seen) instead of by a three-way exact
  match that could not match a dynamic status at all. `DiagnosticsPageTests` (6); captured on the published
  build at 150% scaling.
- [x] **The diagnostics bundle is produced at all.** ✅ **Fixed in this audit.**
  The export read the log tail with `File.ReadAllLines` while the application held the log open for writing.
  That grants only *read* sharing; Windows checks a new handle's sharing against the existing writer's access,
  so the read failed with a sharing violation, the exception escaped `DiagnosticsBundle.Create`, and **every**
  export produced no file whatsoever — on every machine, whenever the app had logged anything. The tail is now
  read with write sharing, and a log that still cannot be read costs its own file (*Log tail unavailable (…)*)
  rather than the whole bundle. Found by pressing the button on the running published build, then driven from
  it to a 7-file bundle; `DiagnosticsBundleTests` (4) holds the log open exactly the way the product does.

## Android backend

- [x] **The transport is shared, so no second COM backend was written.** ✅
  Android phones reach Windows through the same MTP/Windows Portable Devices surface as an iPhone —
  Microsoft lists "Media Transfer Protocol (MTP) music players, **phones**, and cameras" among WPD storage
  devices — so `Devices/Wpd/WpdDevice.cs` keeps one COM implementation and the attached device's family
  selects a storage *policy*. Two near-identical COM backends would have to be fixed twice, and the second
  copy would be the one nobody had a device to test.
  Evidence: [`RESEARCH-SOURCES.md`](RESEARCH-SOURCES.md) §Android.
- [x] **The family is decided from what the device says, never from the device-type hint.** ✅
  `Core/DeviceFamily.cs` classifies from friendly name, manufacturer and model. `WPD_DEVICE_TYPE` is
  deliberately unread: Microsoft says it is used for "the generic visual appearance of the device" and that
  applications "must use the capabilities of the portable device to determine functionally, not the
  **WPD_DEVICE_TYPE** value" — and classification here *is* a functional decision. `DeviceFamilyTests` (10)
  pins both directions, including that an Apple match is strict (`Apple iPhone` stays Apple even against a
  Samsung manufacturer string) and that manufacturer matching is by whole word, so `Volkswagen` is not `LG`
  and `Microtek` is not `MTK`. The asymmetry is deliberate and tested: reading an Android phone as an iPhone
  would back up its camera roll and report a complete scan, while reading an iPhone as generic storage only
  looks in more places.
- [x] **Android storage is walked as whole volumes.** ✅ *(logic)* / ⛔ *(device)*
  An Android phone publishes one storage container per volume ("Internal shared storage", an SD card), and
  `Core/PortableStorage.cs` walks each in full and keeps the volume's own name as its destination folder, so
  an internal volume and a card are never merged. Photos, Videos, Music and Files are all advertised for
  Android because they are genuinely there; an unidentified device keeps the conservative two-group iPhone
  answer. `PortableStorageTests` (13) covers the policy; the walk itself needs a phone.
- [x] **What Android refuses is skipped instead of reported as failure.** ✅ *(logic)*
  `Android\data` and `Android\obb` are not readable by a file-transfer client, so descending would spend a
  device round trip per app collecting errors; thumbnail caches are derived data. Both are skipped, while
  `Android\media` — where apps such as WhatsApp keep photos — is kept, and a user folder merely *called*
  `data` is not skipped at all. Asserted folder by folder.
- [x] **A locked phone, or the wrong USB mode, produces a warning rather than a quietly short backup.** ✅
  *(logic and wording)* / ⛔ *(trigger)*
  A phone in "Transfer photos" (PTP) mode really does expose only `DCIM` and `Pictures`, and a locked phone
  answers with an empty folder; both look like a healthy device with less data. The scan carries a warning
  naming the setting to change, the device message says unlock and choose *File transfer*, and the
  diagnostics page gives USB mode and lock state a row each. The wording says "may be in PTP mode" because
  the sources are community reports, not vendor documentation. `PortableStorageTests` +
  `ConnectionDiagnosticsTests` (5).
- [x] **No Apple wording is shown for an Android device.** ✅
  The dashboard, the device header, the library empty state, the operation idle text, the write refusal and
  the diagnostics rows were all iPhone-specific ("IPHONE READY", "tap Trust", "iCloud originals", "Apple
  software"). Each now follows the detected family, and a device that identifies as neither family is
  reported as **NOT IDENTIFIED** and named in the device message rather than being called a phone it is not.
  `ConnectionDiagnosticsTests`, `MediaCategoriesTests`, `DeviceFamilyTests`.
- [x] **Two phones attached are a choice, not a race.** ✅ *(logic)* / ⛔ *(device trigger)*
  An iPhone and an Android phone on the same desk reach Windows on the same portable-device bus, so "the
  first one WPD lists" was not a decision the operator made. `AppSettings.PreferredHandset` (Settings →
  *When both phones are attached, read*) reorders the two families; it never removes one, so the phone that
  is actually attached is still read when the preferred family is absent, and the phone that is not read is
  named in the connection message. `DeviceFamilyTests` pins the order and the `AppleFirst` default;
  `SettingsTests` pins the round-trip and that an older settings file without the property still means
  iPhone-first. **Live 2026-10-21:** with both attached, `AndroidFirst` selected the HUAWEI and `AppleFirst`
  selected the iPhone; Diagnostics named both. The same session exposed a cross-device scan defect (probe and
  scan could choose different phones; cache key used the probe), now refused by `DeviceSelectionGuard`,
  `ScanResult.BelongsTo`, the MainForm guard and the cache guard. The physical disappearance drill is still
  open (matrix BT08).
- [x] **The Android path has been run against a device for walk, copy, cancel/resume and PTP; the lock abort is not applicable on this MTP stack.** ⛔
  The HUAWEI Y7 Prime 2018 was walked end to end on 2026-10-22: **4,103 files / 15,612,056,299 bytes (14.54
  GiB)**, `Complete`. A filtered copy planned 520 files: **412 source-and-destination SHA-256 verified, 108
  `COPIED-UNVERIFIABLE` (0-byte `Sounds\.pictures`), 0 failed, 3,586 skipped**, ending `COPIED WITH
  UNVERIFIABLE FILES - NOT A VERIFIED COMPLETE BACKUP`; resume preserved the 108 unverified entries and the
  trial stayed at 0 jobs. A 612,420,912-byte MP4 was then cancelled mid-copy and resumed to
  `HASH-VERIFIED COMPLETE`, source/destination SHA-256 identical. A PTP-only handset was checked on 2026-10-24:
  the Overview showed the camera-only warning and the activity log named PTP. The HUAWEI lock does not disable
  MTP, so the locked-phone abort is not applicable to this stack. A single-file Android buffer sweep is now
  live, plus a 30-file mixed-size batch at 6.41 files/s / 23.74 MB/s. These are observations, not a statistical benchmark. TEST-PLAN check 25 is closed for this handset.
- [x] **"Complete" is described honestly for Android.** ✅ *(wording)*
  Windows sees Android's own MTP view of its storage — AOSP's `MtpDatabase` combines `MtpStorageManager`
  filesystem operations with `MediaProvider` metadata — so a complete Android scan means *everything the
  phone exposed*, and the diagnostics page says so instead of implying the filesystem was read.

## Wireless transport

**Browser sender (implemented; local integration tested 2026-10-31).** The receiver serves a real sender
page at `/`, `/send` and the ticket URL. New tickets carry the single-use secret in the fragment
(`/pair#token=...`); `WirelessSenderTests` (6 loopback tests) pin that the secret is absent from the
request target and asset responses, that opening the ticket URL does not spend it, that the JSON pairing
API still accepts the query form, and that the page and script are served with a restrictive CSP.
`tests/sender/sender.test.mjs` checks the page's SHA-256 against OpenSSL across 13 sizes, the path rules,
hash cancellation before and between 4 MiB slices, 24 receipt cases that must fail closed or verify, and
five batch-cancellation sequences whose summary must say `CANCELLED` and never read as complete.
`tests/sender/browser-e2e.mjs` drives Chrome against the real receiver in two phases: the auto-approve
happy path (pair, 64 KiB HEIC, `VERIFIED` receipt, destination bytes identical, second send renamed
` (1)`), and a manual-approval cancellation (cancel while the first file waits; `CANCELLED` +
`NOT ATTEMPTED`, no destination or `.partial` file; the picker/folder/pairing/rotation controls are
disabled during the batch and restored afterwards). `WirelessReceiverTests` also pins a real socket that
disconnects while an offer is pending: the offer is `Cancelled`, the waiting count drops to zero, a late
approval is refused, and the same path can be offered again.

`Require TLS` is a hard requirement: the receiver refuses to start without a certificate whose SAN exactly
matches the bind address (`ServerCertificateValidatorTests`, 14), and clearing it is the only way to run
private-network HTTP. Certificate selection is separate from phone trust: Safari and Chrome still reject a
self-signed certificate until its CA or certificate is trusted on the device, and `docs/WIRELESS.md` lists
what must be installed.

This is a **local browser integration**, not a physical iPhone or Android run. Physical Safari and Android
Chrome sender testing is **pending** (KI-12), and physical sender evidence is **not** release evidence. A
native iOS Shortcut or companion app is a separate capability; it is not shipped here and is not claimed.


- [x] **The pairing secret is short-lived, single-use and is not itself a write credential.** ✅
  `PairingStateTests` (13) and `WirelessReceiverTests` (25, real loopback and private-LAN `TcpListener`): the displayed secret
  is redeemed once for a separate 32-hex-character session token; a second `/pair` with the same secret is
  `401`; presenting the **secret** to `/upload` is `401` and writes nothing; an issued secret invalidates the
  previous one; sessions expire, rotate (the replaced token dies immediately) and are capped at eight.
- [x] **The receiver binds only to a private interface.** ✅
  `PrivateNetworkTests` (21) and `WirelessReceiverTests`: loopback and the three RFC1918 ranges bind, while
  `0.0.0.0`, `*`, `+`, public and carrier-grade (100.64/10) addresses are refused **before** a socket is opened,
  with the reason named. The old address list offered every interface the machine had; that is gone.
- [x] **Show the receiving device and the files, and require approval; never expose an unauthenticated upload.**
  ✅ `ApprovalInboxTests` (13), `WirelessReceiverTests`, `WirelessPageTests` (11). An upload becomes an *offer*
  carrying the sender's address and the path it wants; the response is withheld until the operator decides, and
  a refusal sticks for the session. Approving is a local action only - there is deliberately **no network route
  to approve**. Auto-approval exists as a visible switch, not a silent default. `/upload` without a session is
  `401` and writes nothing. A sender that disconnects while waiting cancels the offer immediately (not after the
  timeout), a late approval cannot commit it, and the same path may be offered again.
- [x] **No firewall port is opened automatically, and TLS is never claimed when it is not there.** ✅
  Nothing in the application touches `netsh advfirewall` or the firewall API. `Require TLS` refuses to start
  unless a certificate in `CurrentUser\My` is valid, has a private key, is suitable for server authentication
  and has an **exact** SAN match for the bind address (`ServerCertificateValidatorTests`, 14). There is no HTTP
  fallback. Private-network HTTP exists only when the operator explicitly clears `Require TLS`; the status line,
  activity log and `/health` then state that the traffic is not encrypted. Server-side selection is distinct
  from phone trust: Safari and Chrome must still trust the certificate chain, and `docs/WIRELESS.md` documents
  the certificate/CA installation steps for both platforms.
- [x] **Unsafe paths, oversized bodies, digest and size disagreement, and collisions are refused.** ✅
  `WirelessReceiverTests`: traversal and `.i-total` are `400`; a declared digest that disagrees is `422` and
  leaves no staging file; a size disagreement is `422`; a volume that cannot hold the declared size is `507`;
  an existing file is renamed rather than overwritten and the receipt records the name actually used; two
  in-flight uploads of the same path are told so (`409`) instead of racing for the same free name.
- [ ] **Wireless from a real iOS/Android browser sender.** **PENDING.**
  Both handsets are attached, but no native iOS Shortcut/companion sender exists in this environment. The
  browser sender is implemented and locally tested (Chrome against the real receiver, plus Node digest,
  receipt, cancellation and TLS-identity tests). It has **not** been run from a physical iPhone Safari or
  Android Chrome, so physical compatibility is not claimed; a native iOS Shortcut or companion app is a
  separate capability, not shipped here. The protocol, pairing, approval, rotation, digest, traversal and
  page-contract rules are covered by loopback tests and were driven live against the published build with a
  real HTTP client, but physical sender evidence is not release evidence until it exists.
- [ ] **Certificate-pinned TLS.** **NO.**
  Not implemented and not claimed. The receiver selects a certificate only when its SAN exactly matches the
  bind address, and `Require TLS` refuses to start when none matches; it does not pin a certificate. Clearing
  `Require TLS` is the explicit operator decision that enables private-network HTTP. A native Shortcut cannot
  pin a self-signed certificate, which is one reason the browser sender is the implemented path; the phones
  must still trust the selected certificate chain.


## Release engineering

- [x] **Build succeeds from a clean checkout on current Visual Studio / .NET SDK.** ✅
  `docs/BUILD-VALIDATION.md`; on 2026-10-24 a fresh `git clone` also built at 0 warnings / 0 errors, passed the full 449-test suite and published the byte-identical `411F4CC5...` executable, and the source zip is built from scratch at 0 warnings / 0 errors.
- [x] **Unit and integration tests pass on Windows.** ✅
  **460 passed, 0 failed, 2 skipped (462 total)** on 2026-10-29 (the two skips are hardware-marked Shell-backend
  apartment tests). The two-phone isolation guard added 14 tests on 2026-10-21; the Appearance preview
  controls added 4, the theme token/contrast coverage was expanded and the no-device neutral-wording
  regression was added on 2026-10-22. Earlier waves include 37 added with the commercial subsystem: 83 for the wireless credential model, the QR encoder,
  the approval gate and the receiver's real HTTP surface; 20 for the USB-evidence diagnosis, the diagnostics
  page contract and the bundle's own export; **30 for the Android work** (`DeviceFamilyTests` 10,
  `PortableStorageTests` 13, `ConnectionDiagnosticsTests` 5, plus one `FolderNameIndexTests` case for the path
  lookup's new root-label rule — a volume is not called `DCIM` — and one `MediaCategoriesTests` case for the
  family-aware group explanation); and **6 for the two-phone session** — three `AttachmentDiagnosisTests` for
  the family filter, one `DeviceFamilyTests` case for the selection order, one `SettingsTests` round-trip and
  one `FilterAndConflictTests` case for the disconnect boundary.
- [x] **Native dependency versions, hashes, licenses and provenance are recorded.** ✅
  `native/dependencies.json` plus `docs/RESEARCH-SOURCES.md`; `DependencyVerifierTests` (6), including
  `ShippedManifestHasNoPinnedBinaryThatCouldSilentlyEnableAfc` — the AFC backend stays inert until an operator
  deliberately pins a binary with a hash.
- [x] **Installer upgrade and uninstall behaviour are tested.** ✓
  `InstallerScriptTests` (6) executes the real per-user installer against temporary folders and a temporary
  HKCU key: install creates the executable, manifest, uninstaller and uninstall entry; upgrade replaces the
  executable while settings and the trial ledger survive; uninstall through the installed copy removes the
  folder and key but keeps user data; a wrong hash exits 4 without writing anything; uninstalling an unrelated
  folder exits 3 without deleting anything. No administrator rights and no firewall rule are involved.
- [x] **The signing path is tested with a temporary certificate; no trusted signature exists.** signtool
  10.0.26100.0 and `installer/Sign-Artifacts.ps1` are present; the script signed a copy of the published exe
  with SHA-256 and `verify /pa` passed while the test certificate was trusted, then the certificate, PFX and
  copy were removed. The PFX-import defect found by the drill is fixed. No signed artifact ships and no
  signature is claimed; the RFC3161 timestamp step could not complete here. See `docs/RELEASE-SIGNING.md`.
- [x] **No silent driver installation or security-setting changes.** ✅
  The installer adds files, a shortcut and an HKCU uninstall entry only; it creates no service, scheduled task,
  firewall rule or driver. The app uses the operating system's own WPD/Shell stack, and
  `DependencyVerifier` refuses an unpinned native binary even when it is present
  (`UnpinnedBinaryIsRefusedEvenWhenPresent`).
- [x] **Logs and exported reports avoid unnecessary private data.** ✅ **Fixed in this audit.**
  Two defects were found and corrected. (1) A **device serial was not redacted at all** — the dashboard line
  `Serial: FCC4L3VYCW` went into `I-total-transfer.log` verbatim, and that log is shipped inside the destination
  folder and inside the diagnostics bundle, whose own README claims it carries no full device identifiers. (2)
  A **secret assignment kept its value**: `pairing_token: …` was rewritten as `pairing_token=…REDACTED …`, which
  reads as redacted and is not. Both are masked now, the label is kept for support, and ordinary operational
  text is left byte-for-byte. `LogRedactionTests` (9), including a check on the file itself.

## Trial, licensing and the commercial gate

- [x] **The trial counts meaningful work, not launches.** A free install gets three jobs. A job is recorded
  only when the transfer completed, was not cancelled, had no failures and wrote at least one file with
  non-zero bytes. Failed, cancelled, empty, partial and "everything was already present" runs cost nothing.
  `LicensingTests`, `JobFacts.IsMeaningful`.
- [x] **The counter survives restarts, updates and the loss of one store.** It lives in
  `%APPDATA%\I-Total Transfer\trial.json` and `HKCU\Software\I-Total Transfer\Trial` and is merged
  pessimistically (highest count, union of job fingerprints, earliest first-seen, latest last-seen). A corrupt
  file is quarantined, not read as a fresh trial. A clock moved backwards cannot reset the count. Tests:
  restart, single-store loss, corruption, clock rollback, read-only ledger.
- [x] **A repeated report cannot consume a second job.** The engine stamps each run with `JobId` and the
  ledger stores a truncated SHA-256 fingerprint; reporting the same finished run again returns
  `AlreadyRecorded`. Tested.
- [x] **A purchased licence is verified offline against a public key only.** Entitlements and revocations are
  RSA-PSS/SHA-256 envelopes. The payload is not parsed until the signature verifies. Missing key means
  `NotConfigured` - never acceptance. No private key, certificate, password or payment secret is in the
  source, the executable or a package. Tampered, expired, not-yet-valid, refunded, revoked, wrong-product,
  wrong-channel and wrong-app-id cases each have a distinct verdict and a test.
- [x] **Licence errors never abort or corrupt an in-progress transfer.** The gate runs only when a new job
  starts; `TryStartJob(resuming: true)` is always allowed. Ledger and store failures are caught, the
  transfer finishes, and the UI reports that the count is memory-only. No timer or background check exists.
- [x] **The operator can see and act on the state.** Settings > Licence shows the live counter, the rule that
  defines a job, an `Enter licence...` picker, and a Buy button that is disabled with its reason when the
  build has no store URL; Steam builds also offer a re-check. `LicenseSettingsTests` drives the real controls.
- [x] **Support can see the counter without seeing the buyer.** The diagnostics bundle carries a
  `licence.txt` summary - standing, channel, jobs used/limit/remaining and the start decision - and never the
  purchase identifier, ledger entries or fingerprints; `trial.json` is not copied. `DiagnosticsBundleTests`
  and a live export from the published build.
- [x] **Wireless reception is metered by the same trial.** One sender session costs one job, charged after the
  first committed and verified file; an exhausted trial refuses new uploads with HTTP 402 and writes nothing.
  Tests: `OneWirelessSenderSessionCostsOneTrialJob`, `AFinishedTrialRefusesNewWirelessUploads`.
- [ ] **A production-issued entitlement has been activated.** BLOCKED BY EXTERNAL REQUIREMENT: no key pair,
  no issuing backend and no purchase URL exist yet, so the shipped build carries no public key and
  `Enter licence...` reports `NotConfigured` while the trial runs. This is fail-closed, and it is recorded
  as pending rather than passed. The same blocker covers a live refund/revocation push.

## Installer, packaging and signing

- [x] **Per-user installation only.** `installer/Install-I-Total.Transfer.ps1` targets
  `%LOCALAPPDATA%\Programs\I-Total Transfer`; no UAC prompt, no machine-wide state, no firewall rule, no
  service, no scheduled task.
- [x] **Hash-checked and manifest-scoped.** `-ExpectedSha256` refuses a mismatched executable before writing
  anything (exit 4). Every installed file is recorded in `install-manifest.json`; uninstall removes only
  those names and refuses a folder it does not own (exit 3).
- [x] **Upgrade and uninstall preserve the operator's data.** Settings, trial ledger, licence, cache and logs
  live under `%APPDATA%\I-Total Transfer` and survive both operations; `-RemoveUserData` deletes only a
  folder carrying this product's own data files.
- [x] **Portable package.** `installer/Build-Installer.ps1` produces the portable ZIP with `INSTALL.txt`
  and `SHA256SUMS.txt` and refuses to package an executable whose hash does not match.
- [x] **Packaged setup executable.** LIVE PASS on 2026-10-24 with Inno Setup 6.7.3. `Build-Installer.ps1`
  produced `I-Total.Transfer-1.8.0-setup.exe`; `/VERYSILENT /DIR=...` installed the exe (hash matches
  `publish\`), uninstaller and Start Menu group, wrote the HKCU entry, created no firewall rule and kept
  `%APPDATA%`; the installed app launched and exited 0; the silent uninstaller removed the folder, key and
  shortcuts and kept the operator data; an upgrade over a running installation closed the app and exited 0. The setup is unsigned.
- [x] **Signing and verification drilled with a temporary self-signed certificate; nothing shipped is
  signed.** signtool 10.0.26100.0 signed a copy of the published exe with SHA-256 and `verify /pa` passed
  while a temporary test certificate was trusted; the release exe and setup stayed `NotSigned`, and the
  certificate and PFX were removed. The drill found and fixed a PFX-import defect (`op_BitwiseOr`) in
  `Sign-Artifacts.ps1`; a signing failure exits 4 and removes the imported certificate. A **trusted**
  certificate is still absent, so 1.8.0 remains unsigned; the RFC3161 timestamp step could not complete
  here (the TSA request hung).
## What this means

**Release-ready today**, with the evidence above: the correctness contract, the engine's performance
behaviour, the destination-safety rules, the privacy of logs and reports, the wireless transport's security
contract (single-use pairing, session rotation, private-only binding, an approval gate that writes nothing
until you decide, and an honest TLS fallback - all of it driven live against the published build, not only
unit-tested), the connection diagnosis (live-verified against this machine's own USB records, so a device
Windows merely remembers can no longer be told apart from one that is there), the diagnostics bundle (driven
from the running build after fixing the defect that had stopped it being written at all), and the ability to
build and test without a device.

**Not yet release-ready**, and the remaining reasons:

1. **Physical handset legs.** A locked/untrusted iPhone, a genuinely cloud-optimised library, a real cable
   pull mid-copy, and the locked/unplugged variants of the USB diagnosis still need the phone attached. The
   buffers, attached diagnosis, mid-scan pull, selected-phone disappearance, Android cancel/resume and PTP
   warning are live and recorded above.
2. **The wireless sender leg.** The receiver is proven; the *sender* is not. No iOS Shortcut or companion app
   has delivered a file from a real handset, so the pairing QR, the approval prompt and the digest check have
   never been exercised by a real client - only by a scripted one. The recipe is ready in `docs/WIRELESS.md`.
3. **Signing.** The per-user installer, the portable ZIP and the Inno Setup `setup.exe` are built and tested
   (the setup was installed, launched and uninstalled silently on 2026-10-24). What remains is an Authenticode
   certificate and the Windows SDK signing tools, so nothing is signed.
4. **Android.** Walk/copy, cancel/resume, PTP, unplug, the single-file buffer sweep and the 30-file batch are
   live; a screen lock is not a disconnect on this MTP stack, and no statistical benchmark is claimed.

Release notes must say exactly this and nothing stronger.
