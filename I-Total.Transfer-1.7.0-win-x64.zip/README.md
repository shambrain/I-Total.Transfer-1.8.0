# I-Total Transfer

**by Deveg** — a Windows desktop app that copies iPhone camera-roll media exposed to Windows over USB
into a user-chosen folder, and (when a verified backend permits) back again. The guiding rule is
simple: **never report a file as transferred unless it can be proven.** Every unverified or failed
item is named explicitly instead of being folded into a success count.

Version **1.7.0** · `net10.0-windows` · WinForms (Designer-authored) with a Fluent control library ·
.NET 10 LTS · runs on Windows 10 1809+ and Windows 11.

---

## What is verified in this workspace

| Check | Result |
| --- | --- |
| `dotnet build I-Total.Transfer.sln -c Release` | **0 warnings, 0 errors** |
| `dotnet test tests\I-Total.Transfer.Tests -c Release` | **90 passed, 0 failed** (includes real loopback wireless, theme palette/migration and media-group tests) |
| App startup smoke test (`I-Total.Transfer.exe`, 6s) | **launches and stays resident, no crash** |
| Release publish (`win-x64`, self-contained, single file) | **produces `publish\I-Total.Transfer.exe`** |

Everything below that involves a real iPhone (WPD/AFC enumeration, throughput, disconnect recovery,
wireless from a real iOS sender) is **hardware-unverified** and labelled as such. No device results
are fabricated.

---

## Backends

The engine talks to a device only through `ITransferBackend`. Concrete backends:

| Backend | Kind | Groups exposed | Read source | Hash source | Write to device | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| **Windows Portable Devices (native)** | WPD | Photos, Videos | yes | yes | no | Read-only COM backend over the DCIM tree. iOS does not expose DCIM for write via WPD. |
| **AFC / libimobiledevice** | AFC | Photos, Videos, Music, Files | yes | yes | yes | Enumerates `/DCIM`, `/iTunes_Control/Music`, `/Recordings`, `/Books`, `/Downloads`, `/Purchases`, skipping and naming roots the device does not expose. **Inert until its pinned native runtime verifies.** |
| **Windows Shell (compatibility)** | Shell | Photos, Videos | read-back only | no | no | `CopyHere` fallback over the shell's DCIM view. Can copy but **cannot** claim source-to-destination integrity. |

`BackendCapabilities.Categories` declares what each backend can reach, and the UI uses it: a group a
backend cannot expose is shown as unavailable rather than as an empty collection.

`BackendFactory` selects by preference (`Auto`/`WPD`/`AFC`/`Shell`) with an explicit, logged fallback
chain. All WPD COM calls run on a dedicated MTA thread so device access is serialized.

### Native dependency safety (fail-closed)

`native/dependencies.json` pins each native binary by SHA-256. On start-up and on the Diagnostics
page, `DependencyVerifier` hashes the on-disk binary and compares it to the pin:

- pinned + matching → **Verified**
- present but no pin → **NotPinned → refused**
- hash differs → **HashMismatch → refused**
- absent → **Missing**

The manifest currently ships with **empty hashes**, so every native binary is refused and the AFC
backend stays inert. That is intentional: dropping an unpinned DLL into `native\` can never enable it.
`docs/BUILD-VALIDATION.md` describes how to pin a reviewed build.

---

## Integrity model

Verification is graded, and the grade is persisted per file (`TransferEntry.Verification`):

| Level | Meaning | Requires |
| --- | --- | --- |
| `None` | nothing proven | — |
| `SizeOnly` | destination size matches the source-reported size | source size known |
| `DestinationHash` | staged payload SHA-256 == committed destination SHA-256 | local staging |
| `SourceAndDestinationHash` | **live source stream SHA-256 == destination SHA-256** | a backend that can read raw source bytes |

The UI and reports never upgrade a file beyond the level actually achieved. A same-size file with no
saved digest is reported **unverifiable**, not verified. Existing destination files are never
overwritten by default; different-size or hash-mismatched collisions are preserved and reported.

Copy pipeline: stream → **staging** (hash while streaming) → **atomic commit** → destination hash →
compare to the strongest available digest. A mismatch fails the item and removes the new commit.

---

## Features

- **Complete enumeration with an explicit report.** A scan is `Complete`, `Incomplete`, `Empty`, or
  `Failed`. A folder that cannot be read produces an `Incomplete` report with the failing folders
  listed — it is never silently omitted. The report distinguishes exposed files from Photos-app
  counts and records Live-Photo pairs and zero-byte/unknown-size items.
- **Resume that cannot lie.** A crash-safe, throttled JSON manifest (`.i-total\session.json`) records
  per-file state, attempt counts and hashes; a SQLite session database (`.i-total\session.db`) keeps
  history and problem-file queries.
- **Filters.** Extension allow-list, folder/name exclusions, sidecar exclusion, and min/max size.
  Excluded files are recorded as skipped, never dropped silently.
- **Conflict policies.** Preserve-and-report (default), skip, rename incoming, or overwrite.
- **Pause / resume / stop** that stay responsive (a cooperative pause gate, not a blocked thread).
- **Wireless receiving** with a short-lived, single-session random pairing token, strict relative-path
  validation, a per-file size cap, SHA-256 on receipt, and a private-interface bind. TLS is used when
  a certificate is bound; otherwise the token-authenticated session runs on the private network only
  and that fact is surfaced in the UI and log.
- **Windows → iPhone** send path (AFC only; refuses to pretend the Shell fallback can write).
- **Settings** persisted under `%APPDATA%\I-Total Transfer\settings.json`, validated/clamped on load,
  with a corrupt file quarantined rather than deleted.
- **Diagnostics bundle** — a redacted ZIP (environment, settings, backend status, dependency status,
  log tail) safe to share.

---

## The interface

The entire UI is declared in **WinForms Designer files** (`*.Designer.cs`) and is openable in the
Visual Studio designer. `MainForm` is a shell (header, navigation rail, content host, status bar)
hosting per-page `UserControl`s, each with its own Designer file:

| Page | What it does |
| --- | --- |
| **Dashboard** | Device state, headline metrics, destination picker, primary actions. |
| **Transfer & queue** | Live progress, throughput/ETA, the persistent per-file queue, log console. |
| **Library & verification** | Filtered browse of the enumerated media; run verification (with optional repair). |
| **Wireless** | Receiver bind settings, pairing ticket/URL, received-file list with per-file SHA-256. |
| **History** | Recent sessions and problem files from the SQLite database. |
| **Settings** | Every option, persisted and clamped. |
| **Diagnostics** | Connection checks, native dependency provenance, diagnostics ZIP export. |

The shell is built from a small Fluent control library (`UI/Controls`): `BrandBand` paints the banner's
navy ramp behind the app header and the page header, `CardPanel`/`MetricCard`/`EmptyState` are rounded,
hairline-bordered surfaces with anti-aliased GDI+ corners at DPI-scaled radii, `RoundedButton` carries an
icon-font glyph and an accent gradient for primary actions, `PillLabel` renders the device-state badge,
and `FluentProgressBar` draws a gradient track with eased motion, a live percentage and an indeterminate
segment when no total is known. `FluentCheckBox`/`FluentRadioButton` replace the native check glyphs so
they follow the active palette exactly, while `ComboBox`, `NumericUpDown`, text boxes and scrollbars
follow the app theme through .NET 10's `Application.SetColorMode`.

The app icon is the supplied glossy squircle artwork, embedded as a nine-frame `app.ico` (16–256 px, so
the shell never has to resample it) and as a 1024 px badge for the header.

### The four media groups

The banner's promise — **Photos · Videos · Music · Files** — is the app's data model, not just a caption.
`Core/MediaCategories.cs` decides membership from the file extension, so a file is in exactly one group
everywhere it appears:

| Group | Tagline shown in the app | Extensions |
| --- | --- | --- |
| Photos | Keep your memories | `jpg jpeg heic heif png dng gif tiff tif bmp webp raw arw cr2 nef` |
| Videos | Big moments, no limits | `mov mp4 m4v avi hevc 3gp mts m2ts` |
| Music | Your sound, your way | `mp3 m4a aac wav flac aiff aif alac ogg opus` |
| Files | Everything in one place | everything else (documents, books, archives) |

The dashboard counts files and bytes per group, the library filters by group, and each backend declares
which groups it can actually expose (`BackendCapabilities.Categories`), so a group that a backend cannot
reach is shown as unavailable instead of silently empty.

### Themes

`UI/Theme.cs` holds the palettes and is selected in **Settings → Theme**:

| Theme | Look |
| --- | --- |
| **Neon** *(default)* | The banner itself: deep navy surfaces (`#040A1E` page, `#0C1A46` card) under a `#011157 → #002785 → #063FA7` band, with the sampled accent ramp `#14F0FC` cyan → `#05A1FC` sky → `#0B55F1` blue → `#222EEC` indigo → `#6F32FB` violet → `#B738FC` purple → `#F334F8` magenta → `#FB45BF` pink. |
| **Slate** | Neutral near-black greys with the brand blue accent — flat, no ramp. |
| **Light** | Light Fluent palette; the band inverts to a near-white ramp and the group accents stay. |
| **Follow Windows** | Resolves to Light or Neon from the OS `AppsUseLightTheme` flag and re-themes live when Windows flips. |

Every colour is sampled from the supplied banner rather than guessed. An existing `settings.json` that
still says `"Theme": "Dark"` loads unchanged and maps to **Neon**, so no preference is lost. Changing the
theme re-themes the whole window in place — no restart, no lost state.

Every control that the UI advertises is wired to a real service call. All Designer files use
`AutoScaleMode.Dpi` against a 96-DPI baseline, so the layout scales **uniformly** on high-DPI displays
(e.g. a 150% 4K/ultrawide screen) instead of stretching; the window is clamped to the monitor working
area and re-clamped when the DPI changes.

---

## Requirements

- Windows 10 1809+ / Windows 11 x64 (Windows 10 is past consumer end of support, but the app still
  targets and builds for it. Dark mode for the Win32 common controls is a Windows 11 feature, so on
  Windows 10 combo boxes use an explicitly themed flat style; spin-box arrows and scrollbars keep the
  OS look. Win11-only DWM features are used when present and skipped when absent.)
- .NET 10 SDK to build, or the .NET 10 Desktop Runtime to run a framework-dependent build
- iPhone unlocked and trusted by Windows, on a data-capable USB cable
- Apple Devices for Windows (or compatible Apple device support)

## Build & run

1. Install the .NET 10 SDK (10.0.100 or newer in the 10.0 feature band).
2. Run `Build-Release.bat` → publishes a self-contained `win-x64` single file under `publish\`.
3. Launch `publish\I-Total.Transfer.exe`.

For development, open `I-Total.Transfer.sln` in Visual Studio 2022 (or run `dotnet build`/`dotnet test`).
`global.json` pins the SDK feature band for deterministic builds.

## Workflow

1. Connect the iPhone, unlock it, accept **Trust**, click **Check connection**.
2. Choose a destination with enough free space, click **Scan iPhone**. A failed/empty scan is refused.
3. Review the enumeration report and warning list. If the count looks low, fix iCloud-origins / cable /
   trust / driver issues and scan again — do not start the backup.
4. **Start full backup.** The engine streams, stages, commits atomically, and derives the strongest
   available verification level per file.
5. **Verify** (Library page) re-checks every path and size and compares stored digests; missing legacy
   digests are reported unverifiable. "Repair missing" re-copies files that are absent.
6. Review `.i-total\session.json`, `.i-total\session.db`, the enumeration report, the verification
   report, and `I-total-transfer.log` in the destination. Export a diagnostics ZIP from Diagnostics.

---

## Known limitations (hardware-unverified)

- **No physical iPhone in the build environment.** WPD/AFC enumeration, real throughput, disconnect
  recovery, and wireless from a real iOS sender have not been hardware-tested.
- **AFC ships disabled.** No native runtime is bundled; it activates only after a pinned runtime is
  installed and verified.
- **Wireless needs an explicit iOS sender.** An iPhone cannot be enumerated over the network on its
  own; a Shortcut or companion app must select assets and POST them. The loopback security behaviour
  *is* covered by automated tests.
- **Enumeration scope.** Windows/AFC expose only media currently available to the host. A successful
  scan is not proof that iCloud-only originals were downloaded.
- **A size match is not identity.** Only the strongest achieved level is ever claimed in the UI/logs.

## License

MIT. See `LICENSE`.

See `CHANGES.md` for the change checklist, `PROJECT-STATUS.md` for the verification boundary, and
`docs/` for architecture, build-validation, test-plan and research notes.
