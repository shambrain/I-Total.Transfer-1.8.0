## 1.7.0 — 2026-10-18 — Fluent redesign built on the brand banner, .NET 10

- **The banner is now the design system, not a decoration.** Every colour in the app is sampled from the supplied artwork: band `#011157 → #002785 → #063FA7`, glow `#2EADE8`, accent `#0B55F1`, and the full accent ramp `#14F0FC` cyan → `#05A1FC` sky → `#0B55F1` blue → `#222EEC` indigo → `#6F32FB` violet → `#B738FC` purple → `#F334F8` magenta → `#FB45BF` pink, plus the warm `#F9945C`/`#FCC146` pair for warnings.
- **New shell.** The window is a fixed navigation rail (grouped *Transfer / Activity / System*, glyph icons, accent-tinted selection) beside a content area under two painted banner bands: the app band (icon, wordmark, tagline, live device-state badge) and the per-page band (page glyph, title, one-line purpose). The page itself is a flat theme surface, so the band is the only place the gradient appears — the same restraint the banner uses.
- **Fluent control library** (`UI/Controls`): `BrandBand`, `CardPanel`, `MetricCard`, `PillLabel`, `RoundedButton`, `FluentProgressBar`, `FluentCheckBox`, `FluentRadioButton`, `EmptyState`, `InfoBar`, `Surface`. Anti-aliased GDI+ corners at DPI-scaled radii, cached fonts, `Segoe UI Variable`/`Segoe Fluent Icons` when present with `Segoe UI`/`Segoe MDL2 Assets` fallbacks on Windows 10.
- **.NET 10, plus native dark chrome where the OS provides it.** `net10.0-windows`, SDK pinned via `global.json`, `Microsoft.Data.Sqlite` 10.0.13. `Application.SetColorMode` (`Classic`/`Dark`/`System`) gives the Win32 common controls the app's colour mode — Microsoft documents that dark mode as **Windows 11 only**, so on Windows 10 combo boxes fall back to an explicitly themed flat style rather than keeping a light drop button, and the remaining native chrome stays as the OS draws it. Window chrome is themed through `DwmSetWindowAttribute`: immersive dark caption on Windows 10 17763+, rounded corners and caption tint on Windows 11 22621+ (each degrades silently when absent).
- **The banner's four groups are the data model.** `MediaCategory` + `MediaCategories.Of(extension)` decide Photos / Videos / Music / Files membership; `MediaSummary` aggregates counts and bytes; `MediaFile.Category` derives from the same rules; `BackendCapabilities.Categories` lets a backend declare which groups it can actually expose. The taglines are used verbatim in the UI: *Keep your memories*, *Big moments, no limits*, *Your sound, your way*, *Everything in one place*.
- **Dashboard rebuilt** around that model: a device hero card, "What your iPhone exposes" with four accent-tinted group tiles, four headline metrics (files found, total size, verified, needs attention), and the destination/actions card with honest policy lines.
- **Library rebuilt:** a filter toolbar (search box, five group chips, repair toggle) over the file grid with an empty state that distinguishes "nothing scanned yet" from "no matches", beside the verification report with one-click destination verification and scan export.
- **Transfer view:** gradient progress bar with eased motion, live percentage, indeterminate mode when no total is known, and throughput/ETA promoted to headline statistics.
- **New app icon:** the supplied glossy squircle embedded as a nine-frame `app.ico` (16, 20, 24, 32, 40, 48, 64, 128 as 32-bit DIBs; 256 as PNG) plus a 1024 px header badge.
- **AFC now enumerates the whole media area** — `/DCIM`, `/iTunes_Control/Music`, `/Recordings`, `/Books`, `/Downloads`, `/Purchases` — skipping roots the device does not expose and naming them in the warnings instead of silently reporting zero files. Write paths resolve relative to the correct root instead of forcing `DCIM/`.
- **Honest availability:** startup runs a silent connection probe so the dashboard is populated immediately; a backend that cannot expose a group shows it as unavailable rather than empty.
- **Tests: 90 passing.** New coverage for the banner palette, `System` resolution (Light or Neon), extension → group mapping, `MediaFile.Category`, group titles/taglines and capability gating.
- Release build 0 warnings / 0 errors; Neon, Slate and Light verified by DPI-aware window captures.
- **Still hardware-unverified (not claimed):** WPD/AFC enumeration and throughput on a physical iPhone, disconnect recovery, wireless from a real iOS sender, and the DWM caption tint on an active Windows 11 window.

## 1.6.0 — 2026-10-17 — verified transfer engine, native backends & Designer UI

- **Integrity first:** graded per-file verification (`SizeOnly` → `DestinationHash` → `SourceAndDestinationHash`); the strongest level actually achieved is persisted and reported. A size match is never reported as byte identity; unreadable items are reported **unverifiable**.
- **Streaming copy pipeline:** stage → hash-while-streaming → atomic commit → destination hash → compare; a mismatch fails the item and removes the new commit. Different-size/hash-mismatched collisions are preserved and reported; nothing is overwritten by default.
- **Complete enumeration:** `EnumerationReport` with `Complete/Incomplete/Empty/Failed`, per-folder outcomes, Live-Photo pairs, zero-byte/unknown-size counts. A folder read failure makes the scan `Incomplete` and is named — never silently omitted.
- **Filters & conflicts:** extension allow-list, folder/name exclusions, sidecar exclusion, min/max size; conflict policies preserve/skip/rename/overwrite.
- **Recoverability:** crash-safe throttled atomic JSON manifest with schema migration + `.bak` recovery; SQLite session database with WAL, batched upserts, history and problem-file queries; resume classification that never overwrites user data.
- **Native WPD backend** (`IPortableDeviceManager/Content/Resources`, read-only, dedicated MTA COM thread, GUIDs taken from Windows SDK headers) and an **AFC** read/write backend that is inert unless its runtime verifies.
- **Fail-closed native dependencies:** `native/dependencies.json` pins binaries by SHA-256; unpinned/mismatched binaries are refused. Ships with empty hashes → no DLLs bundled, AFC disabled.
- **Wireless receiver:** short-lived single-session pairing token, private-interface bind, strict path validation, size cap, SHA-256 on receipt, TLS when a certificate is bound (else token-authenticated private-network HTTP, stated plainly). Fixed a staging-lock bug found by a loopback test.
- **Designer UI:** the whole interface is Designer-authored — a shell (header, nav rail, content host, status bar) plus seven `UserControl` pages (Dashboard, Transfer & queue, Library & verification, Wireless, History, Settings, Diagnostics), each with its own `*.Designer.cs`.
- **Modern shell styling:** cards, the device-status badge and the navigation items are rounded, hairline-bordered surfaces (`CardPanel`, `PillLabel`, `RoundedButton`, `MetricCard`) painted with anti-aliased GDI+ and DPI-scaled radii; the header carries an accent hairline and primary actions/navigation use the accent ramp. The app icon is now the brand artwork — a generated seven-size `app.ico` embedded as both the executable icon and the header badge.
- **Four themes (Neon is the default):** `Neon` (deep navy surfaces with the sampled cyan→sky→blue→violet→magenta accent ramp `#4FEBFC → #24AAF8 → #2F6FE0 → #642CE4 → #D944DA`), `Slate` (neutral near-black greys with the brand blue `#2F6FE0` accent), `Light`, and `Follow Windows`, which reads the OS `AppsUseLightTheme` flag and re-themes live when Windows flips light/dark. A legacy `Dark` value in an existing `settings.json` still loads and maps to `Neon`.
- **High-DPI scaling fixed:** the form and every page now scale **uniformly** via `AutoScaleMode.Dpi` against a 96-DPI design baseline. The previous font-based autoscaling produced a non-uniform stretch (~x1.43 horizontal vs ~x1.67 vertical) that distorted the entire interface on a 150% display. The window is also clamped to the monitor working area and re-clamped on DPI change, so nothing (status bar, buttons) is pushed off-screen at any scale factor.
- **Settings & diagnostics:** validated/clamped settings with corrupt-file quarantine and atomic save; redacted diagnostics ZIP; rolling, redacting, level-aware logging.
- **Tests: 81 passing** (adds settings, dependency-verifier fail-closed, manifest-store recovery, filter/conflict, real loopback wireless, and theme palette/migration tests). Release build 0 warnings/0 errors; self-contained win-x64 publish verified.
- Version 1.6.0; `global.json` pins the SDK feature band.
- **Still hardware-unverified (not claimed):** WPD/AFC enumeration and throughput on a physical iPhone, disconnect recovery, and wireless from a real iOS sender.

## 1.5.0 — 2026-10-17 — verifiable integrity & architecture increment

- Established a working, reproducible build and test baseline (the prior "no .NET SDK" notes were stale; the build machine has .NET 8 SDK 8.0.423).
- Fixed the test project so it actually compiles (missing MSTest `using`); the advertised "12 passing tests" had never been built here.
- Introduced the `ITransferBackend` seam (`Shell` / `Wpd` / `Afc`) and refactored the Shell backend behind it, so the transfer engine, manifests, verification, and recovery are backend-agnostic.
- Added a first-class integrity model: `VerificationLevel` (`None`/`SizeOnly`/`DestinationHash`/`SourceAndDestinationHash`), `TransferEntry.SourceSha256`, and per-entry `Verification`. Session summaries are now labeled by the weakest verification actually achieved; a size match is never reported as more than size verification.
- Hardened `ValidateRelativePath` against reserved Windows device names (CON/PRN/NUL/COM1-9/LPT1-9), trailing dots/spaces, and control characters.
- Made resume/reconciliation and verification classification pure and unit-tested (`ClassifyExistingDestination`, `ClassifyVerification`).
- Fixed a SQLite connection-pooling resource leak (session.db stayed locked); disabled pooling for the per-operation tracker.
- Added a `MockBackend` and end-to-end engine tests (copy, source-vs-staged hashing, resume, collision, empty-scan rejection).
- Test suite: 42 passing. Release build: 0 warnings/0 errors. Self-contained win-x64 publish verified.
- Still outstanding (not claimed): native WPD COM stream backend, pinned/verified AFC runtime, iOS wireless sender, full Designer migration of tab content, and physical-device integration/throughput tests.

## 1.2.0 — 2026-10-16

- Added a WinForms Designer-owned partial class for the form shell and responsive root layout.
- Added a visible device-state dot: green only when the current Shell probe reports accessible iPhone media; black otherwise.
- Made the root layout owned by the Designer partial rather than adding a second root panel at runtime.
- Kept the limitation explicit: device detection still depends on Windows Shell and is not a native WPD enumeration/stream implementation.
- No Windows build or physical-device test was possible in the current environment.

# Changelog

## 1.0.0 — Project foundation

- New product identity: I-total transfer by Deveg.
- Dark Windows Forms dashboard with Transfer, Queue & Reports, Verification, Diagnostics and Settings pages.
- Connection preflight before scanning and again before transfer.
- Windows Shell iPhone media discovery and folder enumeration.
- Scan rejects empty listings, inaccessible folders, unnamed items and duplicate destination paths.
- Optional second full scan to compare paths and reported sizes for library-list consistency.
- Destination free-space check with reserve.
- Staged copying, retries, cancellation, stable-file polling, exact reported-size check, and no overwrite of different-size destination collisions.
- Persistent JSON session manifest plus SQLite session/file/event tracking; CSV/JSON reports.
- Size-based verification with explicit non-cryptographic status; unknown source sizes are marked unverifiable.
- Apple software/driver-file diagnostics, official Apple help links, configurable retry count and keep-awake option.
- Automated unit tests for completion gating, size comparison and path traversal protection.

## Known limitations

- Native WPD resource-stream backend is not yet implemented; the app still uses the Windows Shell compatibility backend.
- Windows Shell CopyHere remains asynchronous and can behave differently across Windows/iOS versions.
- No trusted source hashes are available through the current backend; size matching is not cryptographic integrity verification.
- Driver repair is guided through official Apple resources rather than automatically installing privileged packages.
- Full runtime testing on Windows and physical iPhones is still required.


## 1.1.0 — Architecture and enumeration audit (2026-10-16)

- Added a recursive scan of the exposed DCIM tree; inaccessible child folders abort the scan instead of being silently omitted.
- Added folder caching and `ParseName`-first source lookup to avoid repeatedly enumerating every file in a large folder when the Shell provider supports direct lookup.
- Replaced per-file linear manifest lookup with a case-insensitive dictionary lookup.
- Extended safe relative-path validation to nested folders and added traversal/absolute-path tests.
- Added architecture review, research source register and release acceptance checklist.
- Corrected the proposed backend strategy: AFC is optional/capability-probed, not guaranteed full Photos-library access; native WPD stream backend remains a required engineering milestone.
- No claim of a successful .NET build or physical iPhone integration test is made in this environment.

## 1.1.1 — UI responsiveness and device status
- Changed the Windows application title to `I-Total Transfer` (brand attribution remains inside the application header as “by Deveg”).
- Increased the initial/minimum window size and enabled DPI-aware WinForms scaling to reduce clipping on Windows 10/11 display scaling.
- Repositioned the device status area relative to the header width rather than a hard-coded X coordinate, preventing overlap at different window sizes.
- Added idle-time device polling every five seconds so a connected/unlocked iPhone can update the status without requiring a manual click. Polling is suspended during scans/transfers to avoid concurrent device operations.
- This remains the Windows Shell compatibility backend. These UI changes do not add a native WPD stream backend and do not establish that all iPhone media is exposed by iOS.


## 1.4.0 — staged-payload integrity

- SHA-256 the staged transfer payload before committing it.
- SHA-256 the destination after commit and require exact digest equality.
- Reject and attempt to remove the destination when the staged/destination digests differ.
- Persist both hashes in the manifest.
- Clarify that Shell CopyHere does not provide a raw iPhone source stream; source-to-target identity is not claimed.
- Remaining unimplemented: native WPD COM stream backend, pinned AFC runtime/dependencies, wireless iOS sender/pairing, fully Designer-authored screen layouts, and hardware validation.
