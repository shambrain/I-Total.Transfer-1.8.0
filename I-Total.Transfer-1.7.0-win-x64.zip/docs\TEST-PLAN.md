# Release test plan

The pure safety-rule tests live in `tests/I-Total.Transfer.Tests`. SQLite recovery and session-history integration tests should be added when a Windows test runner is available. Run them on Windows with the .NET 10 SDK:

```powershell
dotnet test .\tests\I-Total.Transfer.Tests\I-Total.Transfer.Tests.csproj -c Release
```

## Required UI regression checks (no device needed)

Run these on both Windows 10 and Windows 11, at 100% and 150% scaling:

1. Switch Neon → Slate → Light → Follow Windows and back; every surface, the two banner bands, the
   group chips, the custom check boxes and the progress bar must re-theme in place with no restart.
2. Open each of the seven pages; nothing may clip, overlap or push the status bar off-screen, and the
   page band must show the right title/subtitle pair.
3. Media library: the five group chips filter using `MediaCategories` (a `.mp3` must appear under
   Music, not Files), the empty state distinguishes "nothing scanned" from "no matches", and the
   summary line reports the filtered and unfiltered counts.
4. With no device: the dashboard must say no iPhone is connected and every group tile must read
   "Connect your iPhone to check" — never a fabricated zero.
5. Keyboard: Tab reaches every action, Enter in the search box applies the filter, and `&` in a device
   name or path is rendered literally (mnemonics are disabled on labels and buttons).

## Required hardware integration tests

Do not label a release device-tested until these tests pass on actual Windows 10 and Windows 11 machines and at least one physical iPhone:

1. iPhone absent, locked, not trusted, and ready states.
2. Charge-only cable, damaged cable, hub disconnect, and reconnect during scan/copy.
3. Folder enumeration exception: scan must fail, never return a complete plan.
4. 0-file listing: must not be accepted as a successful backup.
5. 26,000+ items and a multi-gigabyte video; monitor memory and scan/copy latency.
6. iOS reports a known file size; destination reaches the exact expected size and is unlocked before finalization.
7. Zero-byte file; should not hang forever.
8. Destination has a same-size file with different content: current Shell backend can only report size match, so the test must document this limitation and must not claim cryptographic integrity.
9. Destination collision with a different size: original file must remain untouched and the item must be reported failed.
10. Destination disk full and destination permission denied.
11. Cancel while waiting for a file; the final destination must not contain an incomplete final file.
12. Resume after process termination; already completed files are preserved and remaining items retry.
13. Library changes between scan and copy; missing source item is reported as failed.
14. iCloud Photos with Optimize iPhone Storage enabled and disabled; confirm that not all cloud-only originals are necessarily exposed over USB.
15. Live Photo pairs (HEIC/JPEG + MOV), edited photos, AAE sidecars, duplicate filenames, Unicode names, and long paths.
16. Verify that every incomplete/failed session reports INCOMPLETE and a fully size-matched session says SIZE-VERIFIED, not cryptographically verified.
