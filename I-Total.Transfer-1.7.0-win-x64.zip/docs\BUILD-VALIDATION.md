# Build validation status — v1.7.0

## Executed in this workspace (2026-10-18)

- .NET SDK **10.0.302** (pinned via `global.json` to `10.0.100` with `rollForward: latestFeature`),
  `net10.0-windows`.
- `dotnet build I-Total.Transfer.sln -c Release` → **0 warnings, 0 errors**.
- `dotnet test tests\I-Total.Transfer.Tests -c Release` → **90 passed, 0 failed**.
  Includes real **loopback** wireless tests (binding an `HttpListener`, pairing token, upload,
  SHA-256 on receipt, traversal rejection, `/health`), theme palette/migration tests and media-group
  mapping/gating tests.
- Startup smoke test: the published `I-Total.Transfer.exe` launches and stays resident (no crash).
- `dotnet publish ... -r win-x64 --self-contained true -p:PublishSingleFile=true` → single-file exe;
  `native/dependencies.json` is copied next to it.
- GUI layout check: the window is captured on a 3440x1380 @150% display, once through `PrintWindow`
  (`PW_RENDERFULLCONTENT`, for the client area) and once through `CopyFromScreen` (for the real DWM
  frame). The shell and pages render at a **uniform** scale with no distortion or clipping — Overview,
  Transfer & queue, Media library, Settings and Wireless were inspected, and Neon, Slate and Light were
  each rendered.
- Fluent surface check: both banner bands, rounded cards with hairline borders, the accent gradient on
  primary actions and the selected group chip, the nav selection tint, category accent ramps on the four
  group tiles, the empty state, the gradient progress bar with its percentage caption, and the custom
  check boxes all render; text and symbols (…, →, ·, ●, —) render without mojibake.
- Icon check: `app.ico` is re-read from disk and every one of its nine frames renders the new artwork at
  the correct size.
- `"Follow Windows"` resolution was checked against the live registry flag (`AppsUseLightTheme = 0`).
  `ThemeTests` assert the sampled banner palette values, the default and the legacy-`Dark` migration.

## Not validated here

- No physical iPhone / Apple USB driver stack is attached, so device enumeration, real transfers,
  throughput, disconnect recovery and a real iOS wireless sender are **not** hardware-tested.
- The AFC backend is intentionally inert (see pinning below), so no AFC transfer can occur yet. Its new
  multi-root enumeration is compiled and unit-adjacent code is exercised, but no device has listed
  `/iTunes_Control/Music`, `/Books`, `/Downloads` or `/Purchases` here.
- The `Follow Windows` live re-theme on an OS light/dark flip is coded (`SystemEvents.UserPreferenceChanged`)
  but was not exercised here, since toggling the OS theme was out of scope for this pass.
- Only Windows 11 was available for captures; Windows 10 uses the same code with documented fallbacks
  (Segoe UI / Segoe MDL2 Assets, no rounded corners, immersive dark caption only).

## Pinning the native AFC runtime (fail-closed procedure)

`native/dependencies.json` lists each native binary with a `sha256` pin. An empty pin means the
binary is **refused**, and `DependencyVerifier` never loads it. To enable AFC, a maintainer must:

1. Obtain a reviewed, licensed build of each dependency (libimobiledevice, libplist, libusbmuxd,
   and the OpenSSL `libcrypto` it links).
2. Verify provenance (official release, matching architecture, recorded version).
3. Compute the SHA-256 of each binary.
4. Write the 64-hex-digit digest into the matching `sha256` field.
5. Re-run `dotnet test` — `DependencyVerifierTests` asserts no dependency may be enabled without a pin.
6. Record the pins in the release notes so a user can reproduce them.

Until steps 1–4 are completed for a reviewed build, dragging an arbitrary DLL into `native\` can
never enable the AFC backend.

## Before treating a build as release-ready

Run `Test-Project.bat` and `Build-Release.bat` on Windows 10 and Windows 11, then work through the
hardware checklist in `docs/TEST-PLAN.md` with a physical iPhone.
