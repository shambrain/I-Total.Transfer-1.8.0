# Build status & verification boundary — v1.8.0 (2026-10-20)

This is a complete **source** project, not a signed installer. It is built and tested here, but the
device-facing paths cannot be hardware-verified in this environment.

## Verified in this workspace

| Check | Command | Result |
| --- | --- | --- |
| Release build | `dotnet build I-Total.Transfer.sln -c Release` | ✅ 0 warnings, 0 errors |
| Tests | `dotnet test tests\I-Total.Transfer.Tests -c Release` | ✅ 348 passed, 0 failed, 2 skipped (opt-in hardware tests) - ~25 s, no phone required |
| **Android storage policy** | `DeviceFamilyTests` (11) + `PortableStorageTests` (13) + `ConnectionDiagnosticsTests` (5) | ✅ the family is decided from what the device calls itself (never `WPD_DEVICE_TYPE`, which Microsoft documents as visual only and says must not decide function); an Android phone is walked as **whole volumes**, each keeping its own name as its destination folder; `Android\data`/`Android\obb` and thumbnail caches are skipped while `Android\media` is kept; a camera-only listing raises the PTP warning; the diagnostics rows are family-specific. ⛔ **No app-level Android device result**: a HUAWEI Y7 Prime 2018 was attached once (both volumes readable in Explorer, the presence probe saw it) but the walk and copy never ran |
| **Two phones attached** | `DeviceFamilyTests` + `SettingsTests` + `AttachmentDiagnosisTests` (13) | ✅ Settings → *When both phones are attached, read* reorders the two families without making either unreachable (`AppleFirst` is the default and the enum's zero value, so a pre-Android machine behaves exactly as before); the preference round-trips through `settings.json`, and an older file without the property still means iPhone-first. The Apple USB diagnosis now filters attached devices by family — with an Android phone answering on the same bus it had shown `HUAWEI Y7 Prime 2018` under *"Apple handsets seen over USB"* |
| **Phone unplugged mid-scan (found on hardware)** | live run 2026-10-20 + `FilterAndConflictTests` | ✅ **a real defect**: a 52,574-file iPhone scan reported `status=Complete` after the cable was pulled, with 9,500+ per-object `Shutdown was already called on this object` warnings and a cached "complete" listing missing the tail. Fixed: an unreadable object makes its folder a failed read (`Incomplete`), twenty consecutive failures abort the walk with `DeviceStoppedAnsweringException` and a reconnect instruction, and nothing incomplete reaches the cache. The poisoned listing the pre-fix build wrote was deleted from `%APPDATA%` here. ⛔ the fixed behaviour has not been re-observed on a phone |
| **No-phone diagnostics after the family work** | published 1.8.0 exe, no handset attached, 150% scaling, real capture | ✅ the page leads with `CACHED RECORD ONLY (2)` and carries **`Device family: NOT IDENTIFIED`** (amber) with the explanation that the page describes this PC, not a phone; **`Trust state` reads `CHECK PHONE`** and names both prompts (Trust for an iPhone, File transfer for an Android phone) instead of sending an Android owner after a prompt that never appears; `iCloud originals` is Apple-only, so the page shows 9 checks and no Apple-only advice for an unidentified device; the header is neutral (*Phone to Windows*, *Plug in by USB and unlock the phone*); 7-file bundle exported while running |
| **Wireless security model** | `PairingStateTests` (13) + `ApprovalInboxTests` (9) + `PrivateNetworkTests` (21) | ✅ rules pinned: the displayed pairing secret is single-use and is **refused as an upload credential** (redeeming it mints a separate session token); sessions expire, rotate with the old token dying immediately, are capped at eight and are revoked on Stop; an issued secret invalidates the previous one; an offer waits for the operator, a refusal sticks against a retry, auto-approval is an explicit preference, offers expire; loopback and the three RFC1918 ranges bind, while `0.0.0.0`, `*`, `+`, public and carrier-grade addresses are refused with the reason named |
| **Wireless receiver, real HTTP** | `WirelessReceiverTests` (20, real loopback `HttpListener`) | ✅ genuine sockets, not mocks: unauthorized and secret-as-session uploads are `401` and write nothing; redeeming a secret twice is refused; an offer is visible in the approval list **before any byte is written** and the sender's request only completes on Approve (`200`) or Refuse (`403`); a declared digest that disagrees is `422` and leaves no staging file; traversal and `.i-total` are `400`; an existing file is renamed, not overwritten; rotation retires the old token; the health endpoint never echoes the secret; a public address, the wildcard and `WirelessEnabled = false` all refuse to start; a restart sweeps orphaned staging fragments |
| **Wireless receiver, driven live** | the published `.exe` + a real HTTP client over loopback | ✅ the whole contract observed, not argued: `401` for no credential and for the secret used as a session (nothing written); the secret redeemed once and a second redemption refused as already used; a 1 MiB upload **pending with nothing on disk** until Approve, then `200` with the stored SHA-256 matching the bytes sent; a refusal `403` with a retry of that path refused again; traversal `400`; an approved upload with a mismatched declared digest `422` and **no staging file left**; two concurrent uploads of one name both `200`, the second renamed `IMG_0005 (1).HEIC`. With **Require TLS** on and no certificate bound to the prefix, the receiver fell back and the ticket URL was `http://` - the old build printed `https://` while listening on plain HTTP - the status line named the missing certificate, and `/health` answered `{"status":"ok","tls":false}`. Two UI defects found only in the pixels were fixed: a clipped paragraph and a QR code left on screen after its secret was spent |
| **Wireless page contract** | `WirelessPageTests` (11, real controls) | ✅ Start is disabled until wireless is enabled; a ticket renders both the URL and a visible square QR image; the approval list shows exactly the waiting files with their sender; decided offers are not listed; Approve/Refuse/Approve-all are enabled only when they can act, and Approve raises the **selected** path; changing the auto-approve switch is reported; stopping clears the ticket, the QR and the list |
| **Pairing QR code** | `QrCodeTests` (9) + an independent decoder (`QrDecoder`) | ✅ every payload is read back by a decoder that shares no code with the encoder - format bits, mask, zig-zag walk, block de-interleaving - across every version the encoder claims (1-10, including the multi-block versions 4+), plus the three finder patterns, a 4-module quiet zone, and refusal rather than truncation above the ceiling |
| **Unfinished-session recovery** | `SessionRecoveryTests` (14) + `RecoveryFlowTests` (6) + `DashboardRecoveryTests` (9) | ✅ rules pinned: every entry state counted and outstanding bytes exact; finished/cancelled/aborted/running/never-recorded records read as meant (`INCOMPLETE — NOT A VERIFIED COMPLETE BACKUP` is not mistaken for success); another folder, a newer schema, a damaged record and an unreadable manifest each refused with a reason and the damaged file left in place; the plan carries only outstanding entries with their own sizes/extensions/timestamps and no object identifiers, dropping paths the engine would refuse. Through the real engine: stamped `RUNNING` **before the first byte is fetched**; Stop writes `CANCELLED` with what finished, failed and was never reached; a backend fault writes `ABORTED` and stays continuable; continuing fetches **exactly** the outstanding files (asserted on the backend's fetch log), leaves the verified file untouched, reaches full source-to-destination verification, and refuses to call the session complete while an entry it could never copy is outstanding; a copy whose verification was interrupted is not left in the destination; and a momentarily locked record cannot lose or half-write the record already on disk (`ManifestStoreTests`) |
| **Recovery surface, live** | published 1.8.0 exe + a **seeded** 26,335-entry record (11,143,635 B) | ✅ the Overview bar rendered the record's own numbers (`26,335 planned · 1,203 copied and verified · 25,132 outstanding (12 failed, 4 unreadable)`) and logged the unfinished session **before** "Welcome"; *Not now* collapsed the bar, wrote *"Unfinished session set aside. 25,132 file(s), 172.12 GB, are still outstanding in the destination."* to the status bar, persisted the fingerprint to `settings.json` and left every copied file untouched; with the handset attached the same bar reported **Resume transfer enabled**. It was captured at the machine's real **150% scaling**, where a first capture showed the row measured in the wrong units (the second message line painted outside its card); after the fix the row's following content moved down by exactly 47 device px, the message ends inside the bar, and the fixed capture shows both lines in the card. Construction (the record) was seeded; reading, display, dismissal, the device gating and both layout fixes were the real published build |
| **Engine throughput** | `EngineThroughputBenchmarkTests` (3, real engine, local disk) | ✅ small files **87 → ≈ 700 files/s** (≈ 8x) with verification unchanged; large files ~600 MiB/s (unchanged); measured per-file engine cost ≈ 1.5 ms vs ≈ 27 ms of transport cost per object |
| **Live view pacing** | `ThrottledProgressTests` (5) + the benchmark | ✅ 4,000 engine updates become 21 UI updates at a 250 ms ceiling; the terminal state still comes from the run's summary |
| **Log privacy** | `LogRedactionTests` (9) | ✅ **two defects found by the 2026-10-19 audit and fixed**: a device serial was not redacted at all (the dashboard's `Serial: …` line reached `I-total-transfer.log`, which ships inside the destination and inside a diagnostics bundle whose README claims no full device identifiers), and the credential rule consumed the label but left the value (`pairing_token: …` → `pairing_token=…REDACTED …`). Labelled identifiers (serial/UDID/ECID/IMEI/MEID/stable-or-device id) are now masked to a short prefix, assignments consume their value, and ordinary operational text is unchanged — asserted in both directions, including on the log file itself |
| **Unfinished-session resume cost** | `FolderNameIndexTests` (9) | ✅ a resumed run has no object ids to reuse (they do not survive a reconnect), so it locates each file by path — and it used to re-read the album and a property per sibling **for every file**, quadratic in the album. Each device folder is now read **once per session** and answered from memory, dropped on any session reset: **26,100 files across three albums cost 4 folder reads**. The device-side gain is not measured (needs the handset); the lookup no longer depends on album size |
| **Second-pass scan check** | `ScanStabilityTests` (6) | ✅ the two enumerations are compared by dictionary lookup, not by a scan of the listing per path. Measured: **4,705 ms → 5.7 ms** for 26,000 paths on the UI thread; it no longer throws when a partial (warned) scan carries a duplicate path |
| **Scan-listing cache** | `ScanCacheTests` (9) + `ScanCacheStoreTests` (11) + `LibraryPageProvenanceTests` (4) | ✅ rules pinned: only a `Complete` enumeration is written; a partial/empty scan cannot replace a good listing; another device/backend, an older schema and an over-age listing are refused with a stated reason; corruption is quarantined, never fatal; the device identity is not written into the file name; the backend object id is deliberately not persisted; the difference report counts additions/removals/size changes; the page's provenance line survives the empty state. Live (real app, seeded listing): Settings read **"1 listing, 1,366 B"**, *Forget cached listings* removed it after confirmation and the row read **"No listing is on disk."** |
| **Cache shown during a cold scan** | Needs the handset | ⛔ Unit-tested only. `ShowLastKnownLibrary` runs after the device probe succeeds, so with the iPhone detached it cannot be exercised end to end — the code path and its provenance text are pinned by tests, but no live capture of a cached library beside a running scan exists yet. |
| **Overview operation band** | `OperationStatusTests` (6) + `DashboardOperationBandTests` (3, real controls) | ✅ sweeps while a phase is unmeasured, becomes determinate only with a real total, names the phase, shows nothing when idle; a 106 GB total still yields a correct position (permille, no `int` overflow) |
| **No clipping on a short window** | real capture before/after + `AutoScrollMinSize` on the page | ✅ the integration line was sliced in half once the band was added; the page now scrolls instead of squeezing the action panel |
| **Context capture cannot deadlock a host** | `ContextFreeExecutionTests` (3, pump-required context) | ✅ a blocking caller with a UI context scans, copies and cancels without hanging, and leaves nothing queued on that context |
| iPhone diagnosis | live iPhone 13 Pro, unlocked + trusted, via the app's own Shell call | ✅ storage container found; **no `DCIM` level** — its five camera-roll albums (26,320 files in one) sit directly at the storage root |
| **Live end-to-end detection** | fixed build, reconnected iPhone 13 Pro (iOS 27.0.1, serial `FCC4L3VYCW`) | ✅ native WPD reports Ready; header shows the green blip, `Model: Apple iPhone · iOS: 27.0.1 · Serial: FCC4L3VYCW · Link: USB (WPD)` |
| **USB evidence: remembered vs attached** | `AttachmentDiagnosisTests` (13) + **this machine's own** USB registry | ✅ only the media interface (`WUDFWpdMtp`) counts as a handset, so the support records a PC keeps for every Apple cable it has seen are reported but never counted as phones; a cached iPhone **and** a cached iPad read as `CACHED RECORD ONLY (2)` with nothing attached and never as connected; an attached handset is never downgraded by stale records beside it; a machine that has never seen an Apple device says so and names the driver/cable remedies; Windows' indirect `@…inf,%key%;Readable Name` values resolve to the readable half. Live: a read of this PC's real registry returned `cached handsets=2 (Apple iPhone, Apple iPad); support=3` - the fixture is the machine, not a mock |
| **Connection diagnosis, live** | published 1.8.0 exe, **no handset attached**, real desktop capture at 150% scaling | ✅ Diagnostics led with **CACHED RECORD ONLY (2)** - *Apple iPhone, Apple iPad* - plus the guidance naming Device Manager's own *"Currently, this hardware device is not connected to the computer"* wording, in place of the bare *no device* the app used to show; the summary line repeated the verdict; the detail column wrapped and its row grew, so the whole paragraph was readable (previously long findings were silently cut off at the column edge) |
| **Diagnostics bundle, live** | published 1.8.0 exe + *Export diagnostics ZIP* **while running** | ✅ **a defect found by pressing the button**: the export read the log tail with `File.ReadAllLines` while the application held the log open for writing, so the sharing violation escaped `DiagnosticsBundle.Create` and **every** export produced no file whatsoever. Fixed (write-shared read; an unreadable log now costs only its own file) and re-driven: a **7-file** ZIP - environment, redacted settings, backends, dependencies, `logs-tail.txt`, `context.txt`, README - written from the running build, with `logs-tail.txt` carrying that run's own lines and `context.txt` carrying the same attachment verdict and no hex identifiers |
| **Diagnostics page and bundle contract** | `DiagnosticsPageTests` (6, real controls) + `DiagnosticsBundleTests` (4) | ✅ the USB evidence is the **first** row and its status is shown whole; the three readings are coloured apart (attached green, remembered-only amber, never-seen red - the old three-way exact match could not match a dynamic status at all); findings wrap and their rows grow in both grids; the bundle is produced while the log is held open **exactly** as `LogService` holds it; a serial in the log is masked while the attachment evidence survives redaction verbatim |
| **Live full scan** | the same session, *Scan device* | ✅ `Scan finished: 26,335 files, 106.49 GB, status=Complete, duration=0.1 min` (warm cache, 4.9 s) |
| Live scan totals cross-check | dashboard vs album contents | ✅ 13,021 photos (19.79 GB) + 666 videos (86.69 GB) + sidecars = 26,335; `202608_a` alone holds 26,320 |
| Cold-cache enumeration cost | timed Shell enumeration of `202608_a` | ✅ 723,017 ms for 26,320 items (**≈ 27 ms/object**); warm per-item reads 0.1–0.25 ms |
| Scan progress reporting | `ScanProgressReporterTests` (6 tests) + live log | ✅ throttled, always reports on folder change, formatted pull line routed to the status bar |
| Caption-button contrast | `CaptionButtonContrastTests` (4 tests) + real capture | ✅ ≥ 3:1 on every theme; measured **16.3:1** on Light (glyph `RGB(21,23,28)` on band `RGB(243,244,247)`) vs 1.06:1 before |
| Staged-read-back optimisation | `TransferEngineTests` (2 new tests) | ✅ a source-hashing backend records no staged digest and stays `SourceAndDestinationHash`; a Shell-like backend still reads the payload back |
| Test-suite determinism | full run, repeated, with `--blame-hang` | ✅ completes in ~25 s, 0 failures; hardware tests opt-in and time-bounded; a WinForms `SynchronizationContext` can no longer leak between test classes |
| Camera-roll resolution rules | `CameraRollTests` (8 tests) | ✅ both layouts accepted, verbatim live folder names used, unrelated volumes and sidecars rejected |
| Shell backend apartment | `ShellBackendApartmentTests` (2 tests, opt-in) | ✅ probe answers from an MTA caller, disposes cleanly, no hang |
| Startup smoke test | launch `I-Total.Transfer.exe`, wait 6s | ✅ resident, no crash |
| Publish | `dotnet publish src\I-Total.Transfer\I-Total.Transfer.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true` | ✅ produced single-file exe |
| GUI layout @ 150% DPI | launch + desktop capture (3440x1380 @150%) | ✅ uniform scale, no clipping/distortion — all seven pages captured maximized |
| Fluent surfaces | captures of every page | ✅ banner bands, rounded cards, group accents, chip rows, empty states, gradient progress bar |
| Window chrome | scripted interaction test on the real window | ✅ maximize/restore exact (Δw=0, Δh=0), band drag exact, minimize/restore exact, close exits, caption buttons named |
| Theme apply-on-save | scripted combo-box test + read back `settings.json` | ✅ repaints live, persists `Theme` (Neon → Light) |
| Tile rendering | paint-size/clip logging + window and desktop captures | ✅ inverted-corner seam found and fixed (`MetricCard` was missing `ResizeRedraw`) |
| Theme render | capture Neon (default), Slate, Light | ✅ rounded surfaces, borders, accent gradient, nav highlight, header rule, brand icon, no mojibake |
| Theme logic | `ThemeTests` | ✅ default = Neon, legacy `Dark` → Neon, sampled banner palette values, `System` → Light/Neon |
| Media groups | `MediaCategoriesTests` | ✅ extension mapping, `MediaFile.Category`, titles/taglines, capability gating |
| App icon | load `app.ico`, render every frame | ✅ 9 frames (16–256 px) all render the new artwork |

The wireless receiver is covered by **real loopback network tests** (bind, single-use pairing, session
token rotation and expiry, the approval gate in both directions, upload, SHA-256 on receipt, digest and
size disagreement, traversal and reserved-path rejection, collision renaming, health endpoint, refusal of
public/wildcard binds, staging sweep) - these are genuine network tests speaking HTTP over a real socket,
not mocks. The sender contract they implement is written down in `docs/WIRELESS.md`.

## Not verified here (hardware-dependent)

The build machine is Windows 10 Pro 19045. Apple's USB driver stack **is** present here — Diagnostics reports
Apple software *DETECTED* and the driver files *FOUND* at
`C:\Program Files\Common Files\Apple\Mobile Device Support\Drivers\usbaapl64.inf`. A physical iPhone 13 Pro
**was** attached, unlocked and trusted, long enough to confirm detection and two complete enumerations
(**26,335 files / 106.49 GB**, later **52,574 files / 166.72 GB**), and on 2026-10-20 an Android phone was
attached beside it (both volumes readable in Explorer). Both were then disconnected, and nothing is attached
now, so everything below remains unverified. The mid-scan disconnect that ended the second iPhone run found a
real completeness defect, now fixed (see the table above), but the fixed behaviour has not been seen on a
phone. Nothing device-facing beyond detection and enumeration is claimed as working on hardware:

- **The *attached* branch of the USB diagnosis in its corrected form.** The cached-record branch is verified
  against this machine's own registry (see the table above). The attached branch was observed once, on
  2026-10-20, and it was wrong: with an Android phone answering on the same bus the Apple row read
  `Attached and answering: HUAWEI Y7 Prime 2018`. The family filter now prevents that and the corrected
  wording is unit-tested, but no live handset has produced it; the locked-handset variant (row ATTACHED while
  the media rows explain that media is not readable) has never been observed. TEST-PLAN hardware check 24.

- **A transfer that is really interrupted on a live device and then continued.** The recovery record, the
  plan rebuild, the completeness rule and the interface are covered by the tests and the seeded live check
  above, and the app currently reports a genuine iPhone `Ready` over native WPD — but the device-facing leg
  (a real cancel mid-copy over WPD, followed by a real continuation that fetches only the outstanding files)
  has not been run, because it writes real data to a real disk for minutes and was not run without the
  operator's go-ahead. Everything about the *record* is proven; the USB leg of the continuation is not. The
  path lookup that leg depends on was rewritten on 2026-10-19 (`FolderNameIndex` — each device folder is read
  once per session instead of once per file); its logic is pinned by tests, but the improvement it is meant to
  bring on a real album has not been measured against a handset.
- **On-device transfer throughput and the speed effect of the 1.8.0 engine changes.** The phone
  disconnected while the before/after benchmark was being prepared, so no end-to-end device number is
  claimed for the removal of the per-file existence probe or the redundant staged read-back. Both are
  reasoned from measured call costs and pinned by unit tests (see `docs/PERFORMANCE-AUDIT.md` §5).
- **A cold-cache first scan with the new progress line on screen.** The driver cache was warm by the time
  the reporting build existed; re-observing it needs a device reconnect.
- Native WPD streaming and the Shell `CopyHere` path on a live device.
- AFC read/write (also intentionally inert: no pinned runtime ships — see below).
- Large-video handling and Live Photo pairing on-device.
- **Disconnect recovery during a copy or verify.** A real cable pull *did* happen during a scan on
  2026-10-20: the app survived without crashing, but the scan still called itself complete — the defect now
  fixed. The copy and verify phases have not been interrupted on hardware; they go through the backend-fault
  path pinned by `RecoveryFlowTests.ABackendFaultAbortsTheSessionAndLeavesItResumable`.
- **Any Android device path.** The classifier, storage policy, two-phone preference and diagnostics wording
  are unit-tested, and an Android phone was attached and readable in Explorer, but the app never walked or
  copied from it. No Android count, rate or throughput is claimed. TEST-PLAN hardware check 25.
- Wireless from a real iOS sender (Shortcut/companion app). The protocol, single-use pairing, session
  rotation, approval gate, digest and traversal rules are covered by real loopback HTTP tests, but a
  physical iPhone Shortcut has not been run against the receiver here, so "a real iPhone delivered its
  photos over the LAN" is not claimed. The recipe to run it is in `docs/WIRELESS.md`.
- **Windows 11 rendering:** the app targets `net10.0-windows` with a `Windows 10 1809` minimum. The
  captures and interaction tests here were taken on **Windows 10 Pro (build 19045)**, so DWM rounded
  corners, the native dark scrollbars/titleless dark caption, and `Application.SetColorMode` remain
  guarded code paths rather than verified pixels. Icon-font, `Segoe UI Variable` and rounded-corner
  fallbacks are likewise code paths, not captures.
- **Audible UI feedback:** sounds are synthesised in memory and wired to buttons, check boxes and
  completion/attention events, but this machine's speakers cannot be listened to from the test harness,
  so "a tick is audible when you press a button" is left for a human to confirm.
- **Snap and edge resize:** the band drag, the caption buttons, minimize/restore and close were
  automated; dragging to a screen edge (Aero Snap) and the eight-way edge/corner resize were reasoned
  about from the retained window styles but not scripted here.

## Fail-closed native runtime

`native/dependencies.json` pins native binaries by SHA-256 and **currently ships with empty hashes**.
`DependencyVerifier` therefore refuses every native binary, so the AFC backend cannot load anything
that was not explicitly reviewed and pinned. See `docs/BUILD-VALIDATION.md`.

## To treat a build as release-ready

1. Run `Test-Project.bat` and `Build-Release.bat` on Windows 10 and Windows 11.
2. Complete the hardware checklist in `docs/TEST-PLAN.md` with a physical iPhone (ideally two iOS
   versions, Live Photos, a >1 GB video, and iCloud "Optimize Storage" on and off).
3. Only then claim device results. Until then, describe the device paths as implemented-but-unverified.

## Definition of "verified" in this app

The app claims, at most, the strongest verification level it actually achieved per file
(`SizeOnly` → `DestinationHash` → `SourceAndDestinationHash`). A size match is never reported as
byte identity, and an item that cannot be re-read is reported **unverifiable**, not successful.

## Release artifacts (built here, 2026-10-20)

| Artifact | Size | SHA-256 |
| --- | --- | --- |
| `publish\I-Total.Transfer.exe` (self-contained, single file, win-x64) | 112,056,134 B | `7612BBBE4FC5E27F9A9E259067BE0EF5BA53558C01CB2A57B07D5D6A7FDDFA99` |
| `I-Total.Transfer-1.8.0-win-x64.zip` (deployment) | see `dist\SHA256SUMS.txt` | see `dist\SHA256SUMS.txt` |
| `dist\I-Total.Transfer-1.8.0-source.zip` (complete source) | see `dist\SHA256SUMS.txt` | see `dist\SHA256SUMS.txt` |

`dist\SHA256SUMS.txt` is the **authoritative** record for the two archives, deliberately kept outside
them: this file ships inside both archives, so an archive cannot carry a correct hash of itself. The exe
hash above is stable and reproducible from `publish\` at any time.

These figures supersede the earlier 1.8.0 values (`C4B0DFE1…`, then `D094452C…`, then `A6D6E843…`, then
`362A5BDF…`, then `D9609BF4…`, then `AE679E79…` for the exe and `3BF0D1D4…`, then `AB08B0C8…`, then
`43602D4B…`, then `16B78EB7…`, then `187C5085…` for the deployment ZIP), each of which described a publish
taken before the next round of work: `C4B0DFE1` predates the detection fix, `D094452C` predates the
scan-progress, Overview-band, context-capture and caption-contrast work, `A6D6E843` predates the
engine-throughput and progress-pacing fixes, `362A5BDF` predates the scan-listing cache, `D9609BF4` predates
the unfinished-session recovery work, and `AE679E79` predates the 150% scaling fix for the recovery row and
the retry on the session record. `527BF4EC.` was the publish that followed those, carrying the 2026-10-19
audit fixes (the redaction of device identifiers, the linear second-pass comparison, the once-per-folder
path lookup a resumed run uses) and the wireless rewrite: the single-use pairing secret, session-token
rotation, the approval gate, the private-only bind policy, the hand-written QR encoder, and the two
interface defects the live drill surfaced (a clipped paragraph and a QR code left on screen after its
secret had been spent). `8A591FDC.` added the USB-evidence diagnosis that tells a device Windows merely
remembers from one that is attached, the diagnostics page's no-truncation fix, and the support-bundle export
fix (no bundle had ever been written while the app was running). The hash above (`7612BBBE.`) is the final
publish for this release and adds the Android work (one family-aware WPD backend with a per-family storage
policy, family-aware wording and diagnostics), the two-phone preference, the mid-scan disconnect guard, and
the neutral unattached-device wording (`CHECK PHONE` with both prompts, no Apple-only advice for an
unidentified device). An intermediate publish (`83517885.`) carried the same functional work but the old
unattached wording; it was superseded within the same round. The deployment
ZIP's embedded copy of the exe was **extracted and hash-compared against `publish\`** during packaging — they
match, which is what "verified archive" means here rather than a merely unopened ZIP. The six shipped
documents
(`docs\TEST-PLAN.md`, `docs\BUILD-VALIDATION.md`, `docs\PERFORMANCE-AUDIT.md`, `docs\RECOVERY.md`,
`docs\RELEASE-ACCEPTANCE.md`, `docs\WIRELESS.md`) were
hash-compared against the source tree during packaging and are byte-identical. The deployment ZIP also
carries this file, `CHANGELOG.md` and the test/performance documents, so a recipient can see the
verification boundary without the source tree. The source ZIP is extracted and **rebuilt clean
(0 warnings / 0 errors)** as part of packaging, which is the check that it is complete rather than merely
unopened.

The deployment ZIP contains the exe, `native\dependencies.json` (kept outside the single-file bundle so
pins can be edited without a rebuild), `README.md`, `CHANGELOG.md`, `LICENSE`, `PROJECT-STATUS.md`, and
`docs\{TEST-PLAN,BUILD-VALIDATION,PERFORMANCE-AUDIT,RECOVERY,RELEASE-ACCEPTANCE,WIRELESS}.md`. The source ZIP contains the complete
solution
(excluding `bin`/`obj`/`publish`/`dist` and intermediate archives), including `.Designer.cs` files, tests
and build scripts. The published exe reports `FileVersion 1.8.0.0` / `ProductVersion 1.8.0` and was
smoke-tested through its own UI on this exact build: launched and driven via UI Automation to Settings (where
the Backend section's new row read **"When both phones are attached, read — the iPhone"** at 150% scaling,
with nothing clipped) and to Diagnostics (which led with **`CACHED RECORD ONLY (2)`**, carried
**`Device family: NOT IDENTIFIED`**, read **`CHECK PHONE`** for the trust row, and exported a 7-file bundle
while the application held its log open). The earlier Performance-row read-back — the concurrency control
reporting `enabled=False` with its label, and "Copy buffer size" as a live combo box — still holds.
