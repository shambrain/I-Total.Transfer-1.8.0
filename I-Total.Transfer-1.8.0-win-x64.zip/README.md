# I-Total Transfer

**by Deveg** — a Windows desktop app that copies media exposed to Windows over USB from a phone into a
user-chosen folder, and (when a verified backend permits) back again. It reads iPhones (camera roll) and
Android phones (whole storage volumes) through the same transport. The guiding rule is
simple: **never report a file as transferred unless it can be proven.** Every unverified or failed
item is named explicitly instead of being folded into a success count.

Version **1.8.0** · `net10.0-windows` · WinForms (Designer-authored) with a Fluent control library ·
.NET 10 LTS · runs on Windows 10 1809+ and Windows 11.

The window is borderless: the banner band doubles as the title bar (minimize / maximize / close painted
on the gradient, drag to move, double-click to zoom), while DWM still supplies the shadow, Aero Snap and
the Alt+Space system menu.

---

## What is verified in this workspace

| Check | Result |
| --- | --- |
| `dotnet build I-Total.Transfer.sln -c Release` | **0 warnings, 0 errors** |
| `dotnet test tests\I-Total.Transfer.Tests -c Release` | **348 passed, 0 failed, 2 skipped** (opt-in hardware tests; includes real loopback wireless - single-use pairing, rotation, the approval gate, digest/traversal rejection - the pairing QR proven by an independent decoder, the wireless page contract on real controls, theme palette/migration, media-group, camera-roll resolution, the Android device-family classifier and generic-MTP storage policy, the family-aware diagnostics rows, the two-phone preference order, the Apple-only attachment filter, the mid-scan disconnect guard, scan-cache provenance, progress-pacing, engine-throughput benchmarks, unfinished-session recovery through the real engine, the recovery surface's layout contract, log redaction in both directions, the second-pass scan comparison, the resumed-run path lookup, the "remembered vs attached" USB diagnosis built on this machine's real records, the diagnostics page's own contract, and the diagnostics bundle's export) |
| App startup smoke test (`I-Total.Transfer.exe`, 6s) | **launches and stays resident, no crash** |
| Release publish (`win-x64`, self-contained, single file) | **produces `publish\I-Total.Transfer.exe`** |
| iPhone diagnosis (live iPhone 13 Pro, via the app's own Shell call) | **device and storage container found; the container holds the camera-roll albums directly and has no `DCIM` level** — the cause of "connected but no DCIM container" |
| Window chrome (automated interaction test) | **maximize/restore returns the exact rectangle (Δw=0, Δh=0); band drag moves by exactly the pointer delta; minimize/restore exact; close exits** |
| Theme apply-on-save (automated) | **selecting Light repaints live and writes `Theme = Light` to `settings.json`** |
| Page layout at 150% DPI | **all seven pages captured maximized, nothing clipped** |
| Scan-listing cache (live app, seeded listing) | **Settings shows "1 listing, 1,366 B"; the *Forget cached listings* confirmation removes it and the row updates to "No listing is on disk." with "Removed 1 cached library listing(s)." in the status bar** |
| USB evidence, live on this machine's real records | **Diagnostics reads `CACHED RECORD ONLY (2)` — *Apple iPhone, Apple iPad* — with 3 support records and nothing attached**, instead of reporting a remembered device as a connected one; the same verdict travels in the bundle. With nothing identified, the page also carries **`Device family: NOT IDENTIFIED`** and a **`CHECK PHONE`** trust row naming both prompts (Trust for an iPhone, File transfer for an Android phone) rather than an Apple-only one |
| Diagnostics bundle (published build, while running) | **a 7-file ZIP is written — environment, redacted settings, backends, dependencies, `logs-tail.txt`, `context.txt`, README** — where before this round *no* bundle was produced at all |
| Two phones attached at once (live, 2026-10-20) | **an iPhone 13 Pro and a HUAWEI Y7 Prime 2018 were both listed under "This PC"**; Explorer enumerated the iPhone's twelve album folders and the Huawei's *SD card* and *Internal storage* volumes, and the app's presence probe saw the Android phone. The iPhone scan then ran for 23.2 min and counted **52,574 files / 166.72 GB** |
| Phone unplugged mid-scan (live, 2026-10-20) | **the run exposed a real defect**: the scan reported `status=Complete` while the disconnected phone made every later object unreadable. Objects that cannot be read now make the scan `Incomplete`, twenty consecutive failures abort the walk with an instruction to reconnect, and no incomplete listing is cached |

Everything below that involves a real phone's *files* — throughput, a genuinely cancelled-and-resumed copy,
disconnect recovery, the *attached* branch of the USB diagnosis, wireless from a real iOS sender, and the
whole Android device path — is **hardware-unverified** and labelled as such. Detection and enumeration have
been run against a real iPhone (see the table); the Android phone was attached and readable in Explorer but
the app-level Android walk and copy never ran, so no Android device result is claimed. No device result is
fabricated.

---

## Backends

The engine talks to a device only through `ITransferBackend`. Concrete backends:

| Backend | Kind | Groups exposed | Read source | Hash source | Write to device | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| **Windows Portable Devices (native)** | WPD | iPhone: Photos, Videos. Android: all four. | yes | yes | no | One read-only COM backend with a per-family storage policy. An **iPhone** is read as a camera roll — a `DCIM` container, or the storage container itself when the driver publishes the albums directly. An **Android phone** is read as whole storage volumes (internal storage, SD card), each keeping its own name as its destination folder. Neither exposes a writable view through WPD that this app should use. |
| **AFC / libimobiledevice** | AFC | Photos, Videos, Music, Files | yes | yes | yes | Enumerates `/DCIM`, `/iTunes_Control/Music`, `/Recordings`, `/Books`, `/Downloads`, `/Purchases`, skipping and naming roots the device does not expose. **Inert until its pinned native runtime verifies.** |
| **Windows Shell (compatibility)** | Shell | Photos, Videos | read-back only | no | no | `CopyHere` fallback over the shell's camera-roll view (both layouts), run entirely on one STA thread. Can copy but **cannot** claim source-to-destination integrity. |

`BackendCapabilities.Categories` declares what each backend can reach, and the UI uses it: a group a
backend cannot expose is shown as unavailable rather than as an empty collection.

`BackendFactory` selects by preference (`Auto`/`WPD`/`AFC`/`Shell`) with an explicit, logged fallback
chain. All WPD COM calls run on a dedicated MTA thread so device access is serialized.

### Native dependency safety (fail-closed)

`native/dependencies.json` pins each native binary by SHA-256. On start-up and on the Diagnostics
page, `DependencyVerifier` hashes the on-disk binary and compares it to the pin:

- pinned + matching → **Verified**
- present but no pin → **NotPinned → refused**
- hash differs → **HashMismatch → refused**
- absent → **Missing**

The manifest currently ships with **empty hashes**, so every native binary is refused and the AFC
backend stays inert. That is intentional: dropping an unpinned DLL into `native\` can never enable it.
`docs/BUILD-VALIDATION.md` describes how to pin a reviewed build.

---

## Integrity model

Verification is graded, and the grade is persisted per file (`TransferEntry.Verification`):

| Level | Meaning | Requires |
| --- | --- | --- |
| `None` | nothing proven | — |
| `SizeOnly` | destination size matches the source-reported size | source size known |
| `DestinationHash` | staged payload SHA-256 == committed destination SHA-256 | local staging |
| `SourceAndDestinationHash` | **live source stream SHA-256 == destination SHA-256** | a backend that can read raw source bytes |

The staged read-back is only paid for when it is the *only* comparison available. A backend that hashes
raw source bytes while streaming already knows the source digest, so re-reading the staged file would cost
a second full pass over every byte — 106 GB on the test handset — and could only ever compare the copy
with itself. Comparing the streamed source digest with the committed destination is both cheaper and
stronger: it also catches a bad read, not just a bad write. Backends that cannot hash source bytes (the
Shell compatibility backend) still get the staged read-back, and which path ran is recorded per file
rather than assumed.

The UI and reports never upgrade a file beyond the level actually achieved. A same-size file with no
saved digest is reported **unverifiable**, not verified. Existing destination files are never
overwritten by default; different-size or hash-mismatched collisions are preserved and reported.

Copy pipeline: stream → **staging** (hash while streaming) → **atomic commit** → destination hash →
compare against the strongest digest available (the streamed source digest, or the staged payload read
back when the backend cannot hash source bytes). A mismatch fails the item and removes the new commit.

Measured behaviour, the audit that produced the 1.8.0 performance work, and everything that is
deliberately left unclaimed are recorded in [`docs/PERFORMANCE-AUDIT.md`](docs/PERFORMANCE-AUDIT.md).

---

## Features

- **Complete enumeration with an explicit report.** A scan is `Complete`, `Incomplete`, `Empty`, or
  `Failed`. A folder that cannot be read produces an `Incomplete` report with the failing folders
  listed — it is never silently omitted. The report distinguishes exposed files from Photos-app
  counts and records Live-Photo pairs and zero-byte/unknown-size items. An object that cannot be read now
  makes its folder a failed read, and twenty failures in a row abort the walk with an instruction to
  reconnect — a phone unplugged mid-scan can no longer produce a "complete" listing of the part the app
  happened to see first.
- **Resume that cannot lie.** A crash-safe, throttled JSON manifest (`.i-total\session.json`) records
  per-file state, attempt counts and hashes; a SQLite session database (`.i-total\session.db`) keeps
  history and problem-file queries.
- **An unfinished transfer is visible, and it can be continued.** The destination folder is stamped
  `RUNNING` before the first byte moves, `CANCELLED` on a Stop and `ABORTED` on a fault, so a job that was
  killed with no chance to write anything is still identifiable by the stamp it left at the start. The
  Overview then shows an inline bar with the folder's own numbers and a **Resume transfer** action — with
  **Not now** to set it aside, remembered against that session alone so later progress always brings it
  back. Continuing rebuilds the plan from the record instead of re-enumerating the phone (a 26,335-entry
  record with 25,132 outstanding rebuilds as a 25,132-file / 172 GB plan), fetches **only** the outstanding
  files, and hashes every one of them again: nothing is trusted on the strength of the record. Files already
  verified are left alone rather than re-read, the session can only be declared complete when **nothing
  anywhere in it** is failed, unreadable, unverified or untried, and a copy whose verification was
  interrupted is discarded rather than left in the folder at a quietly weaker grade. See
  [`docs/RECOVERY.md`](docs/RECOVERY.md).
- **Last known library while a cold scan runs.** A cold camera roll is enumerated by the device at
  roughly 27 ms per *object* (measured: ~12 minutes for one 26,000-item album), during which the library
  page used to be simply empty. The last complete listing of each device is kept under
  `%APPDATA%\I-Total Transfer\scan-cache\` and shown immediately, marked *Last known library (captured …)*
  — never as the result of the run in progress. The live scan still runs, still replaces it, and reports
  what changed (added / removed / changed size). Only `Complete` enumerations are ever written, so a
  partial listing cannot overwrite a good one; a listing is refused if it is older than the configured
  age, from another device or backend, or from an older schema. The Settings page shows what is on disk
  and can delete it, and the feature can be switched off entirely.
- **Filters.** Extension allow-list, folder/name exclusions, sidecar exclusion, and min/max size.
  Excluded files are recorded as skipped, never dropped silently.
- **Conflict policies.** Preserve-and-report (default), skip, rename incoming, or overwrite.
- **Pause / resume / stop** that stay responsive (a cooperative pause gate, not a blocked thread).
- **Two phones, one choice.** An iPhone and an Android phone reach Windows on the same portable-device bus.
  Settings → *When both phones are attached, read* chooses which family is read first; the preference only
  reorders and still falls back when the preferred family is absent, and the phone that is not read is named
  in the connection message and on the Diagnostics page.
- **Wireless receiving** with a single-use pairing secret (shown as a URL and a scannable QR code),
  session tokens minted from it that expire, rotate and are revoked on Stop, strict relative-path
  validation, a per-file size cap, SHA-256 verified on receipt, and a private-interface bind. Incoming
  files wait in an approval list until the operator accepts them - and nothing is written to the folder
  until then - unless automatic approval is explicitly switched on. TLS is used when a certificate is
  bound; otherwise the token-authenticated session runs on the private network only and that fact is
  surfaced in the UI, the log and `/health`. The full sender contract is in `docs/WIRELESS.md`.
- **Windows → iPhone** send path (AFC only; refuses to pretend the Shell fallback can write).
- **Settings** persisted under `%APPDATA%\I-Total Transfer\settings.json`, validated/clamped on load,
  with a corrupt file quarantined rather than deleted.
- **Diagnostics bundle** — a redacted ZIP (environment, settings, backend status, dependency status,
  log tail) safe to share. Redaction is applied to the bundle's own contents *and* to every line the log
  receives: device serials, UDIDs and stable ids are masked to a short prefix, credentials are removed
  whole, and ordinary operational lines are left untouched (see `docs/RELEASE-ACCEPTANCE.md`, release
  engineering).

---

## The interface

The entire UI is declared in **WinForms Designer files** (`*.Designer.cs`) and is openable in the
Visual Studio designer. `MainForm` is a shell (header, navigation rail, content host, status bar)
hosting per-page `UserControl`s, each with its own Designer file:

| Page | What it does |
| --- | --- |
| **Dashboard** | Device state, headline metrics, destination picker, primary actions. |
| **Transfer & queue** | Live progress, throughput/ETA, the persistent per-file queue, log console. |
| **Library & verification** | Filtered browse of the enumerated media; run verification (with optional repair). |
| **Wireless** | Receiver bind settings, single-use pairing ticket with QR code, approval list for incoming files, received-file list with per-file SHA-256. |
| **History** | Recent sessions and problem files from the SQLite database. |
| **Settings** | Every option, persisted and clamped. |
| **Diagnostics** | USB evidence (which handsets are attached vs which Windows merely remembers), connection checks, native dependency provenance, diagnostics ZIP export. |

The shell is built from a small Fluent control library (`UI/Controls`): `BrandBand` paints the banner's
navy ramp behind the app header and the page header, `CardPanel`/`MetricCard`/`EmptyState` are rounded,
hairline-bordered surfaces with anti-aliased GDI+ corners at DPI-scaled radii, `RoundedButton` carries an
icon-font glyph and an accent gradient for primary actions, `PillLabel` renders the device-state badge,
and `FluentProgressBar` draws a gradient track with eased motion, a live percentage and an indeterminate
segment when no total is known. `FluentCheckBox`/`FluentRadioButton` replace the native check glyphs so
they follow the active palette exactly, while `ComboBox`, `NumericUpDown`, text boxes and scrollbars
follow the app theme through .NET 10's `Application.SetColorMode`.

The app icon is the supplied glossy squircle artwork, embedded as a nine-frame `app.ico` (16–256 px, so
the shell never has to resample it) and as a 1024 px badge for the header.

### The four media groups

The banner's promise — **Photos · Videos · Music · Files** — is the app's data model, not just a caption.
`Core/MediaCategories.cs` decides membership from the file extension, so a file is in exactly one group
everywhere it appears:

| Group | Tagline shown in the app | Extensions |
| --- | --- | --- |
| Photos | Keep your memories | `jpg jpeg heic heif png dng gif tiff tif bmp webp raw arw cr2 nef` |
| Videos | Big moments, no limits | `mov mp4 m4v avi hevc 3gp mts m2ts` |
| Music | Your sound, your way | `mp3 m4a aac wav flac aiff aif alac ogg opus` |
| Files | Everything in one place | everything else (documents, books, archives) |

The dashboard counts files and bytes per group, the library filters by group, and each backend declares
which groups it can actually expose (`BackendCapabilities.Categories`), so a group that a backend cannot
reach is shown as unavailable instead of silently empty.

### Themes

`UI/Theme.cs` holds the palettes and is selected in **Settings → Theme**:

| Theme | Look |
| --- | --- |
| **Neon** *(default)* | The banner itself: deep navy surfaces (`#040A1E` page, `#0C1A46` card) under a `#011157 → #002785 → #063FA7` band, with the sampled accent ramp `#14F0FC` cyan → `#05A1FC` sky → `#0B55F1` blue → `#222EEC` indigo → `#6F32FB` violet → `#B738FC` purple → `#F334F8` magenta → `#FB45BF` pink. |
| **Slate** | Neutral near-black greys with the brand blue accent — flat, no ramp. |
| **Light** | Light Fluent palette; the band inverts to a near-white ramp and the group accents stay. |
| **Follow Windows** | Resolves to Light or Neon from the OS `AppsUseLightTheme` flag and re-themes live when Windows flips. |

Every colour is sampled from the supplied banner rather than guessed. An existing `settings.json` that
still says `"Theme": "Dark"` loads unchanged and maps to **Neon**, so no preference is lost. Changing the
theme re-themes the whole window in place — no restart, no lost state.

Every control that the UI advertises is wired to a real service call. All Designer files use
`AutoScaleMode.Dpi` against a 96-DPI baseline, so the layout scales **uniformly** on high-DPI displays
(e.g. a 150% 4K/ultrawide screen) instead of stretching; the window is clamped to the monitor working
area and re-clamped when the DPI changes.

---

## Requirements

- Windows 10 1809+ / Windows 11 x64 (Windows 10 is past consumer end of support, but the app still
  targets and builds for it. Dark mode for the Win32 common controls is a Windows 11 feature, so on
  Windows 10 combo boxes use an explicitly themed flat style; spin-box arrows and scrollbars keep the
  OS look. Win11-only DWM features are used when present and skipped when absent.)
- .NET 10 SDK to build, or the .NET 10 Desktop Runtime to run a framework-dependent build
- iPhone unlocked and trusted by Windows, on a data-capable USB cable
- Apple Devices for Windows (or compatible Apple device support)

## Build & run

1. Install the .NET 10 SDK (10.0.100 or newer in the 10.0 feature band).
2. Run `Build-Release.bat` → publishes a self-contained `win-x64` single file under `publish\`.
3. Launch `publish\I-Total.Transfer.exe`.

For development, open `I-Total.Transfer.sln` in Visual Studio 2022 (or run `dotnet build`/`dotnet test`).
`global.json` pins the SDK feature band for deterministic builds.

## Workflow

1. Connect the iPhone, unlock it, accept **Trust**, click **Check connection**.
2. Choose a destination with enough free space, click **Scan iPhone**. A failed/empty scan is refused.
3. Review the enumeration report and warning list. If the count looks low, fix iCloud-origins / cable /
   trust / driver issues and scan again — do not start the backup.
4. **Start full backup.** The engine streams, stages, commits atomically, and derives the strongest
   available verification level per file.
5. **Verify** (Library page) re-checks every path and size and compares stored digests; missing legacy
   digests are reported unverifiable. "Repair missing" re-copies files that are absent.
6. Review `.i-total\session.json`, `.i-total\session.db`, the enumeration report, the verification
   report, and `I-total-transfer.log` in the destination. Export a diagnostics ZIP from Diagnostics.

---

## Known limitations (hardware-unverified)

- **What is still hardware-unverified.** The corrected build *has* been run against a reconnected iPhone
  13 Pro: it detected the handset over native WPD (`Ready — iPhone media is accessible through native WPD
  (hash-verified transfers available)`), enumerated the whole camera roll (`status=Complete`), and the
  unfinished-session bar reported its action enabled while the phone was attached. Two sessions have been
  counted: **26,335 files / 106.49 GB**, and later **52,574 files / 166.72 GB in 23.2 minutes** after more
  media was added — the second run was cut off by a physical disconnect, which is what exposed the
  scan-completion defect described below. What remains unmeasured is the device-facing work: a real
  device-to-disk transfer benchmark (MB/s, files/s, CPU, peak memory), a transfer that is really cancelled
  mid-copy and then continued, the *attached* branch of the USB diagnosis (the cached-record branch is
  verified against this machine's own USB registry), and wireless from a real iOS sender. Wireless security
  behaviour *is* covered by loopback tests and a live drill against the published build. No device result is
  claimed beyond the detection, the enumeration and the interface gating above.
- **Android has been *seen* but never *read by the app*.** A HUAWEI Y7 Prime 2018 was attached on
  2026-10-20: Windows listed it under "This PC", Explorer enumerated both of its volumes (*SD card*,
  *Internal storage* — including a 1,209-entry `music` folder), and the app's presence probe saw it. The
  app-level Android path — selection with both families attached, the volume walk, a copy from the phone,
  the locked-screen and PTP behaviour the warning describes, and any Android performance measurement — never
  ran, because the phones were disconnected before that drill could start. The classifier, the generic-MTP
  storage policy (whole volumes, the `Android\data`/`Android\obb` skips, the PTP warning), the two-phone
  preference order and the family-aware diagnostics rows are pinned by tests. No Android throughput,
  enumeration rate or buffer behaviour is claimed anywhere in this release. TEST-PLAN hardware check 25 is
  the open item.
- **AFC ships disabled.** No native runtime is bundled; it activates only after a pinned runtime is
  installed and verified.
- **Wireless needs an explicit iOS sender.** An iPhone cannot be enumerated over the network on its
  own; a Shortcut or companion app must select assets and POST them. The protocol, single-use pairing,
  approval gate, rotation, digest and traversal rules *are* covered by loopback tests **and** were driven
  live against the published executable with a real HTTP client (an upload with no credential or with the
  secret-as-session is refused and writes nothing; a file waits in the approval list with nothing on disk
  until accepted; a refusal sticks; traversal, digest mismatch and over-capacity are refused; a name clash
  is renamed rather than overwritten; and with TLS requested but no certificate bound the ticket says
  `http://` and `/health` says `tls:false`). What is still **not** done here is the other end of the wire:
  no physical iPhone Shortcut has delivered a file to this receiver. The contract is in `docs/WIRELESS.md`.
- **Enumeration scope.** Windows/AFC expose only media currently available to the host, and an Android
  phone exposes its own MTP view of its storage rather than a raw filesystem walk, so a complete scan means
  *everything the device offered*. A successful scan is not proof that iCloud-only originals were
  downloaded, nor that an Android app's private directory was readable.
- **A size match is not identity.** Only the strongest achieved level is ever claimed in the UI/logs.

## License

MIT. See `LICENSE`.

See `CHANGES.md` for the change checklist, `PROJECT-STATUS.md` for the verification boundary, and
`docs/` for architecture, build-validation, test-plan and research notes.
