# Wireless transport

The receiver is a real HTTP(S) endpoint on one private interface. It is **not** a way to enumerate an
iPhone: iOS exposes no LAN API for the Photos library, so an explicit sender — a Shortcut or a
companion app — must select the assets and send them. What follows is the complete contract that
sender has to implement, the security model it operates under, and the exact limits of what this
transport proves.

## What the receiver guarantees

| Guarantee | How it is enforced |
| --- | --- |
| It listens only on a private IPv4 interface | `PrivateNetwork` validates the bind address; `0.0.0.0`, `*`, public and carrier-grade addresses are refused before a socket is opened. |
| It never starts unless the operator enabled it | `AppSettings.WirelessEnabled` is checked in `Start()`. |
| Nothing is written without the operator's decision | Every upload is an *offer* held in `ApprovalInbox`. The response is only sent after the operator approves or refuses, unless automatic approval was explicitly switched on. The request body is not even read while an offer is pending, so a refused file never reaches the disk - only an approved one is streamed to staging, hashed and committed. |
| A displayed secret cannot be replayed | The pairing secret is single-use. Redeeming it mints a separate session token; the secret is refused as an upload credential. |
| Credentials expire and rotate | Session tokens have a bounded lifetime (default one hour), can be rotated by the sender, are revoked on Stop, and are capped at eight live sessions. |
| Paths cannot escape the destination | `TransferRules.ValidateRelativePath` plus a reserved-path check (`.i-total`, the log file). |
| Bytes are what the sender said they were | SHA-256 is computed while streaming; a declared `X-Content-Sha256` that disagrees discards the payload. Size is checked against `Content-Length`. |
| An existing file is never overwritten | Collision policy is rename-incoming; the receipt records the name actually used. |
| No firewall rule is created | Nothing in the application calls `netsh advfirewall` or the firewall COM API. |

## Endpoints

| Method | Path | Credential | Purpose |
| --- | --- | --- | --- |
| `GET` | `/health` | none | Liveness and whether TLS is active. Never returns a secret. |
| `POST` | `/pair` | `X-Pairing-Secret: <secret>` | Redeems the single-use secret. Returns a session token **once**. |
| `POST` | `/rotate` | `X-Session-Token` | Retires the presented token and returns a new one. |
| `POST` | `/upload?path=DCIM/IMG_0001.HEIC` | `X-Session-Token` | Offers one file. Waits for the operator's decision. |

`X-Pairing-Token` is accepted as an alias for `X-Session-Token` so an early sender build keeps
working, but its value must be a **session token** — the pairing secret is rejected.

### Pair

```
POST /pair
X-Pairing-Secret: 8f3c…   (32 hex characters, single use)

200 {"status":"paired","session":"…","expiresUtc":"…","tls":false}
401 {"error":"pairing failed","detail":"That pairing secret has already been used. …"}
```

The secret is spent the moment it is **successfully** redeemed. A wrong secret changes nothing, so a typo
does not burn the ticket; presenting the right secret a second time is refused as already used. Ask for a
new ticket in the application — and when a redemption succeeds, the ticket withdraws its own URL and QR
code, so a spent credential is never left looking scannable.

### Upload

```
POST /upload?path=DCIM/IMG_0001.HEIC
X-Session-Token: …
X-Content-Sha256: <optional, lowercase hex>   (recommended: the receiver verifies it)
Content-Length: <exact byte count>
Content-Type: application/octet-stream
```

| Status | Meaning |
| --- | --- |
| `200` | Approved, received, digest verified, committed. Body: `{path, bytes, sha256}`. |
| `400` | Missing or unsafe path, or a reserved path. |
| `401` | No session, expired session, or the secret presented as a session. |
| `403` | The operator refused this file (or did not decide before the offer expired). |
| `409` | Another upload for the same path is already waiting for approval. With automatic approval on, both proceed and the second is renamed instead. |
| `413` | Larger than the 8 GiB per-file cap. |
| `422` | Declared digest or declared size disagreed with the bytes; nothing was kept. Checked **after** the operator's decision, because the body is not read while an offer is pending. |
| `507` | The volume cannot hold the declared size. |

The sender should treat anything but `200` as "not delivered" and retry later with a fresh pairing
ticket. A `403` is a decision, not a transient failure: the same path stays refused for the session.

### Rotate

```
POST /rotate
X-Session-Token: …

200 {"session":"…","expiresUtc":"…"}
```

The old token stops working immediately. Rotate before a long batch rather than widening the lifetime.

## Sender recipe (iOS Shortcut)

Shortcuts can perform the whole flow without a companion app:

1. **Get Contents of URL** — `POST` to the pairing URL shown as a QR code, with header
   `X-Pairing-Secret`. Read `session` from the JSON response.
2. **Select Photos** (or *Get Latest Photos* with a count).
3. **Repeat with Each** — for every photo:
   - *Get Contents of URL*, method `POST`, URL `http://<address>:<port>/upload?path=DCIM/<filename>`,
     header `X-Session-Token: <session>`, request body *File*.
   - Check the status code. `200` means the operator approved it; anything else means it was not
     delivered.
4. Optionally **Get Contents of URL** to `/rotate` between batches.

`path` must be a relative path. The receiver accepts forward slashes and converts them for the
filesystem; a bare filename is placed under `DCIM`.

## TLS

`WirelessRequireTls` asks for `https://`. Windows only serves that prefix when a certificate is bound
to it, which needs an elevated command:

```
netsh http add sslcert ipport=192.168.1.24:47821 certhash=<thumbprint> appid={...}
```

Without that binding the receiver **does not silently claim** TLS: it falls back to the
token-authenticated session on the private interface, sets `UsingTls = false`, and says so in the
status line, the activity log and the `/health` response. There is no certificate pinning; an iOS
Shortcut cannot validate a self-signed certificate, which is why the authenticated-session fallback
exists rather than a self-signed TLS mode that no sender could use.

Confirmed on the published build with **Require TLS** switched on and no certificate bound: the ticket
carried an `http://` URL, the status line read "(private-network HTTP - no certificate bound)", and
`/health` answered `{"status":"ok","tls":false}`. An earlier build advertised `https://` in the ticket
while actually listening on plain HTTP; that mismatch is what this behaviour replaces.

**What this does and does not protect.** On a private network the session is authenticated (an
unpaired client cannot upload, and an unapproved file is not written), but the payload is not
encrypted in transit when TLS is not bound. Treat the Wi-Fi network as trusted, or bind a certificate.

## Limits

- **No enumeration.** The receiver cannot ask an iPhone for its library; the sender must choose files.
- **No background transfer.** A Shortcut runs while it runs. iOS may suspend it when the screen locks;
  the receiver will see the connection end and discard the partial file.
- **No resume of a partial upload.** A failed POST starts again from zero.
- **HEIC/ProRAW conversion is the sender's job.** Bytes are stored exactly as sent.
- **Not verified against a physical sender.** The protocol, pairing, approval, digest, traversal and
  rotation rules are covered by loopback tests (`WirelessReceiverTests` 20, `PairingStateTests` 13,
  `ApprovalInboxTests` 9, `PrivateNetworkTests` 21, `WirelessPageTests` 11) **and** were driven live against
  the published executable with a real HTTP client: `401` for no credential and for the secret used as a
  session, single-use redemption, a 1 MiB upload pending with nothing on disk until Approve, `403` on
  refusal with the refusal sticking, `400` on traversal, `422` and no staging file on a digest mismatch, and
  rename-under-collision. A real iPhone Shortcut has still not been run against it, so the sender leg is
  recorded as an open item in `docs/RELEASE-ACCEPTANCE.md`.
